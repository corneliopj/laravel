<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AveController;
use App\Http\Controllers\TipoAveController;
use App\Http\Controllers\LoteController;
use App\Http\Controllers\IncubacaoController;
use App\Http\Controllers\VariacaoController;
use App\Http\Controllers\AcasalamentoController;
use App\Http\Controllers\PosturaOvoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Rotas de Autenticação (não protegidas pelo middleware 'auth' inicialmente)
Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('login', [AuthController::class, 'login']);
Route::post('logout', [AuthController::class, 'logout'])->name('logout');

// Rotas de Registro (apenas para administradores, a verificação está no controlador)
Route::get('register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('register', [AuthController::class, 'register']);

// Rota Pública para a Certidão (NÃO PROTEGIDA POR AUTENTICAÇÃO)
Route::get('certidao/{validation_code}', [AveController::class, 'showCertidaoPublica'])->name('certidao.show');


// Grupo de rotas que exigem autenticação
Route::middleware(['auth'])->group(function () {
    // Rota para o Dashboard (página inicial)
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Rotas de Recurso para Aves, excluindo 'show' para defini-la explicitamente
    // Isso garante que o Model Binding para {ave} funcione corretamente
    Route::resource('aves', AveController::class)->except(['show']);
    Route::get('aves/{ave}', [AveController::class, 'show'])->name('aves.show');

    // Rotas adicionais para Aves (fora do CRUD padrão)
    Route::get('aves/{ave}/register-death', [AveController::class, 'registerDeath'])->name('aves.registerDeath');
    Route::post('aves/{ave}/store-death', [AveController::class, 'storeDeath'])->name('aves.storeDeath');
    Route::post('aves/{ave}/expedir-certidao', [AveController::class, 'expedirCertidao'])->name('aves.expedirCertidao'); // Rota para expedir certidão
    Route::get('aves/search-suggestions', [AveController::class, 'searchSuggestions'])->name('aves.searchSuggestions'); // Rota para sugestões de busca
    Route::get('aves/search', [AveController::class, 'search'])->name('aves.search'); // Rota para busca completa


    // Rotas de Recurso para Tipos de Aves
    Route::resource('tipos_aves', TipoAveController::class);

    // Rotas de Recurso para Variações
    Route::resource('variacoes', VariacaoController::class);

    // Rotas de Recurso para Lotes
    Route::resource('lotes', LoteController::class);

    // Rotas de Recurso para Incubações
    Route::resource('incubacoes', IncubacaoController::class);

    // Rotas de Recurso para Acasalamentos
    Route::resource('acasalamentos', AcasalamentoController::class);

    // Rotas de Recurso para Posturas de Ovos
    Route::resource('posturas_ovos', PosturaOvoController::class);
    // Rotas adicionais para Postura de Ovos
    Route::post('posturas_ovos/{postura_ovo}/incrementar-ovos', [PosturaOvoController::class, 'incrementOvos'])->name('posturas_ovos.incrementOvos');
    Route::post('posturas_ovos/{postura_ovo}/encerrar', [PosturaOvoController::class, 'encerrarPostura'])->name('posturas_ovos.encerrar');
});
