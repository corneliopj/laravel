<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Incubacao extends Model
{
    use HasFactory;

    // Define o nome da tabela no banco de dados se for diferente do plural do nome do modelo (incubacoes)
    protected $table = 'incubacoes';

    // Define as colunas que podem ser preenchidas massivamente (Mass Assignment)
    protected $fillable = [
        'lote_ovos_id',            // Chave estrangeira para o lote de ovos
        'tipo_ave_id',             // Chave estrangeira para o tipo de ave
        'data_entrada_incubadora', // Data em que os ovos entraram na incubadora
        'data_prevista_eclosao',   // Data prevista para a eclosão
        'quantidade_ovos',         // Número total de ovos colocados para incubar
        'quantidade_eclodidos',    // Número de aves que eclodiram (opcional, pode ser atualizado depois)
        'observacoes',             // Quaisquer observações relevantes sobre a incubação
        'ativo',                   // Status de atividade da incubação (booleano)
        'postura_ovo_id',          // NOVO: Chave estrangeira para a postura de ovos
    ];

    // Define os tipos de dados para colunas específicas para que o Eloquent as trate corretamente
    protected $casts = [
        'data_entrada_incubadora' => 'date',   // Converte para objeto Carbon (data)
        'data_prevista_eclosao'   => 'date',   // Converte para objeto Carbon (data)
        'ativo'                   => 'boolean',  // Converte para booleano
    ];

    // --- Definição de Relações do Modelo ---

    /**
     * Uma incubação pertence a um Lote de Ovos (opcional).
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function loteOvos()
    {
        return $this->belongsTo(Lote::class, 'lote_ovos_id');
    }

    /**
     * Uma incubação está associada a um Tipo de Ave.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tipoAve()
    {
        return $this->belongsTo(TipoAve::class, 'tipo_ave_id');
    }

    /**
     * Uma incubação pode ter muitas Aves que eclodiram dela.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function aves()
    {
        return $this->hasMany(Ave::class, 'incubacao_id');
    }

    /**
     * Uma incubação pertence a uma PosturaOvo.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function posturaOvo() // NOVO: Relação com PosturaOvo
    {
        return $this->belongsTo(PosturaOvo::class, 'postura_ovo_id');
    }
}
