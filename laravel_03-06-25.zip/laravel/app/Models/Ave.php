<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Ave extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'aves';

    protected $fillable = [
        'matricula',
        'validation_code', // NOVO: Adicionado para o código de validação da certidão
        'tipo_ave_id',
        'variacao_id',
        'sexo',
        'data_eclosao',
        'vendavel',
        'lote_id',
        'incubacao_id',
        'foto_path',
    ];

    protected $casts = [
        'data_eclosao' => 'date',
        'vendavel'     => 'boolean',
        'ativo'        => 'boolean', // Certifique-se que 'ativo' também é um booleano
        'data_inativado' => 'datetime', // Certifique-se que 'data_inativado' é datetime
    ];

    public function tipoAve()
    {
        return $this->belongsTo(TipoAve::class);
    }

    public function variacao()
    {
        return $this->belongsTo(Variacao::class);
    }

    public function lote()
    {
        return $this->belongsTo(Lote::class);
    }

    public function morte()
    {
        return $this->hasOne(Morte::class);
    }

    public function incubacao()
    {
        return $this->belongsTo(Incubacao::class);
    }
}
