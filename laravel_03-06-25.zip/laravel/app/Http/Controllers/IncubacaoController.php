<?php

namespace App\Http\Controllers;

use App\Models\Incubacao; // Importa o Model Incubacao
use App\Models\Lote; // Importa o Model Lote para o dropdown
use App\Models\TipoAve; // NOVO: Importa o Model TipoAve
use Illuminate\Http\Request; // Importa a classe Request para lidar com requisições HTTP
use Illuminate\Validation\Rule; // Importa a classe Rule para validação de unicidade
use Carbon\Carbon; // NOVO: Importa Carbon para manipulação de datas

class IncubacaoController extends Controller
{
    /**
     * Exibe uma lista de todas as incubações.
     */
    public function index()
    {
        // Busca todas as incubações, carregando as relações loteOvos e tipoAve e ordenando
        $incubacoes = Incubacao::with('loteOvos', 'tipoAve')->orderBy('data_entrada_incubadora', 'desc')->get();
        
        // Retorna a view de listagem de incubações, passando os dados
        return view('incubacoes.listar', compact('incubacoes'));
    }

    /**
     * Exibe o formulário para criar uma nova incubação.
     */
    public function create()
    {
        // Busca os lotes ativos para o dropdown de lote_ovos_id
        $lotes = Lote::where('ativo', 1)->get();
        // NOVO: Busca todos os tipos de aves para o dropdown de tipo_ave_id
        $tiposAves = TipoAve::all(); 
        
        return view('incubacoes.criar', compact('lotes', 'tiposAves')); // Passa ambos os dados
    }

    /**
     * Armazena uma nova incubação no banco de dados.
     */
    public function store(Request $request)
    {
        // Validação dos dados da requisição
        $request->validate([
            'lote_ovos_id' => 'nullable|integer|exists:lotes,id', // Opcional, inteiro, deve existir na tabela 'lotes'
            'tipo_ave_id' => 'required|integer|exists:tipos_aves,id', // NOVO: Obrigatório, deve existir na tabela 'tipos_aves'
            'data_entrada_incubadora' => 'required|date', // Obrigatória, formato de data
            // Removido 'data_prevista_eclosao' do required, pois será calculado
            'quantidade_ovos' => 'required|integer|min:1', // Obrigatória, inteiro, mínimo 1
            'quantidade_eclodidos' => 'nullable|integer|min:0|lte:quantidade_ovos', // Opcional, inteiro, mínimo 0, <= quantidade_ovos
            'observacoes' => 'nullable|string', // Opcional, texto
            'ativo' => 'boolean', // Ativo é um booleano (opcional, padrão 1 no DB)
        ], [
            'tipo_ave_id.required' => 'O tipo de ave é obrigatório.',
            'data_entrada_incubadora.required' => 'A data de entrada na incubadora é obrigatória.',
            'quantidade_ovos.required' => 'A quantidade de ovos é obrigatória.',
            'quantidade_ovos.min' => 'A quantidade de ovos deve ser no mínimo 1.',
            'quantidade_eclodidos.lte' => 'A quantidade de eclodidos não pode ser maior que a quantidade de ovos.',
        ]);

        try {
            // NOVO: Calcula a data prevista de eclosão
            $tipoAve = TipoAve::find($request->tipo_ave_id);
            if (!$tipoAve || !isset($tipoAve->tempo_eclosao)) {
                return redirect()->back()->withInput()->with('error', 'Erro: Tempo de eclosão não definido para o tipo de ave selecionado.');
            }
            $dataEntrada = Carbon::parse($request->data_entrada_incubadora);
            $dataPrevistaEclosao = $dataEntrada->addDays($tipoAve->tempo_eclosao);

            // Cria a incubação usando o Eloquent ORM
            Incubacao::create([
                'lote_ovos_id' => $request->lote_ovos_id,
                'tipo_ave_id' => $request->tipo_ave_id, // NOVO: Adicionado
                'data_entrada_incubadora' => $request->data_entrada_incubadora,
                'data_prevista_eclosao' => $dataPrevistaEclosao->format('Y-m-d'), // Usa a data calculada
                'quantidade_ovos' => $request->quantidade_ovos,
                'quantidade_eclodidos' => $request->quantidade_eclodidos ?? 0, // Garante 0 se não for fornecido
                'observacoes' => $request->observacoes,
                'ativo' => $request->has('ativo') ? 1 : 0, // checkbox
            ]);

            // Redireciona com mensagem de sucesso
            return redirect()->route('incubacoes.index')->with('success', 'Incubação registada com sucesso!');

        } catch (\Exception $e) {
            // Log do erro para depuração
            \Log::error('Erro ao registar incubação: ' . $e->getMessage(), ['request_data' => $request->all()]);
            // Redireciona de volta com mensagem de erro
            return redirect()->back()->withInput()->with('error', 'Erro ao registar a incubação: ' . $e->getMessage());
        }
    }

    /**
     * Exibe o formulário para editar uma incubação existente.
     */
    public function edit(string $id)
    {
        $incubacao = Incubacao::find($id); // Busca a incubação pelo ID

        if (!$incubacao) {
            return redirect()->route('incubacoes.index')->with('error', 'Incubação não encontrada.');
        }

        $lotes = Lote::where('ativo', 1)->get(); // Busca os lotes ativos para o dropdown
        $tiposAves = TipoAve::all(); // NOVO: Busca todos os tipos de aves para o dropdown

        return view('incubacoes.editar', compact('incubacao', 'lotes', 'tiposAves')); // Passa tiposAves
    }

    /**
     * Atualiza uma incubação existente no banco de dados.
     */
    public function update(Request $request, string $id)
    {
        // Validação dos dados da requisição
        $request->validate([
            'lote_ovos_id' => 'nullable|integer|exists:lotes,id',
            'tipo_ave_id' => 'required|integer|exists:tipos_aves,id', // NOVO: Adicionado
            'data_entrada_incubadora' => 'required|date',
            // Removido 'data_prevista_eclosao' do required, pois será calculado
            'quantidade_ovos' => 'required|integer|min:1',
            'quantidade_eclodidos' => 'nullable|integer|min:0|lte:quantidade_ovos',
            'observacoes' => 'nullable|string',
            'ativo' => 'boolean',
        ], [
            'tipo_ave_id.required' => 'O tipo de ave é obrigatório.',
            'data_entrada_incubadora.required' => 'A data de entrada na incubadora é obrigatória.',
            'quantidade_ovos.required' => 'A quantidade de ovos é obrigatória.',
            'quantidade_ovos.min' => 'A quantidade de ovos deve ser no mínimo 1.',
            'quantidade_eclodidos.lte' => 'A quantidade de eclodidos não pode ser maior que a quantidade de ovos.',
        ]);

        try {
            $incubacao = Incubacao::find($id);

            if (!$incubacao) {
                return redirect()->back()->with('error', 'Incubação não encontrada para atualização.');
            }

            // NOVO: Recalcula a data prevista de eclosão (mesma lógica do store)
            $tipoAve = TipoAve::find($request->tipo_ave_id);
            if (!$tipoAve || !isset($tipoAve->tempo_eclosao)) {
                return redirect()->back()->withInput()->with('error', 'Erro: Tempo de eclosão não definido para o tipo de ave selecionado.');
            }
            $dataEntrada = Carbon::parse($request->data_entrada_incubadora);
            $dataPrevistaEclosao = $dataEntrada->addDays($tipoAve->tempo_eclosao);

            $incubacao->update([
                'lote_ovos_id' => $request->lote_ovos_id,
                'tipo_ave_id' => $request->tipo_ave_id, // NOVO: Adicionado
                'data_entrada_incubadora' => $request->data_entrada_incubadora,
                'data_prevista_eclosao' => $dataPrevistaEclosao->format('Y-m-d'), // Usa a data recalculada
                'quantidade_ovos' => $request->quantidade_ovos,
                'quantidade_eclodidos' => $request->quantidade_eclodidos ?? 0,
                'observacoes' => $request->observacoes,
                'ativo' => $request->has('ativo') ? 1 : 0,
            ]);

            return redirect()->route('incubacoes.index')->with('success', 'Incubação atualizada com sucesso!');

        } catch (\Exception $e) {
            \Log::error('Erro ao atualizar incubação: ' . $e->getMessage(), ['request_data' => $request->all()]);
            return redirect()->back()->withInput()->with('error', 'Erro ao atualizar a incubação: ' . $e->getMessage());
        }
    }

    /**
     * Inativa uma incubação do banco de dados (inativação lógica).
     */
    public function destroy(string $id)
    {
        try {
            $incubacao = Incubacao::find($id);

            if (!$incubacao) {
                return redirect()->route('incubacoes.index')->with('error', 'Incubação não encontrada para inativação.');
            }

            // Verifica se há aves associadas a esta incubação antes de inativar
            // A relação 'aves' no Model de Incubacao deve ser atualizada para usar 'incubacao_id'
            // no Model de Ave, se essa for a chave estrangeira.
            if ($incubacao->aves()->count() > 0) {
                return redirect()->route('incubacoes.index')->with('error', 'Não é possível inativar esta incubação, pois existem aves associadas a ela.');
            }

            // Inativação lógica da incubação
            $incubacao->update([
                'ativo' => 0,
            ]);

            return redirect()->route('incubacoes.index')->with('success', 'Incubação inativada com sucesso!');

        } catch (\Exception $e) {
            \Log::error('Erro ao inativar incubação: ' . $e->getMessage(), ['incubacao_id' => $id]);
            return redirect()->route('incubacoes.index')->with('error', 'Erro ao inativar a incubação.');
        }
    }
}
