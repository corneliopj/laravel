<?php

namespace App\Http\Controllers;

use App\Models\Ave;
use App\Models\Incubacao;
use App\Models\Morte;
use App\Models\TipoAve;
use Illuminate\Http\Request;
use Carbon\Carbon; // Para manipulação de datas

class DashboardController extends Controller
{
    /**
     * Exibe o dashboard com um resumo dos dados.
     */
    public function index()
    {
        // 1. Quantidade Total de Aves Ativas
        $totalAvesAtivas = Ave::where('ativo', 1)->count();

        // 2. Mortes nos Últimos 30 Dias
        $dataLimite = Carbon::now()->subDays(30);
        $mortesUltimos30Dias = Morte::where('data_morte', '>=', $dataLimite)->count();

        // 3. Aves por Tipo (para Gráfico de Pizza)
        // Busca a contagem de aves por tipo e o nome do tipo
        $avesPorTipo = Ave::select('tipo_ave_id')
                            ->selectRaw('count(*) as total')
                            ->where('ativo', 1)
                            ->groupBy('tipo_ave_id')
                            ->with('tipoAve') // Carrega a relação para obter o nome do tipo
                            ->get();

        $labelsAvesPorTipo = $avesPorTipo->map(function($item) {
            return $item->tipoAve->nome ?? 'Desconhecido';
        });
        $dataAvesPorTipo = $avesPorTipo->map(function($item) {
            return $item->total;
        });

        // 4. Resumo de Incubações
        $totalIncubacoesAtivas = Incubacao::where('ativo', 1)->count();
        $totalOvosIncubados = Incubacao::sum('quantidade_ovos');
        $totalEclodidos = Incubacao::sum('quantidade_eclodidos');
        $taxaEclosao = ($totalOvosIncubados > 0) ? round(($totalEclodidos / $totalOvosIncubados) * 100, 2) : 0;

        // Passa os dados para a view
        return view('dashboard.index', compact(
            'totalAvesAtivas',
            'mortesUltimos30Dias',
            'labelsAvesPorTipo',
            'dataAvesPorTipo',
            'totalIncubacoesAtivas',
            'totalOvosIncubados',
            'totalEclodidos',
            'taxaEclosao'
        ));
    }
}
