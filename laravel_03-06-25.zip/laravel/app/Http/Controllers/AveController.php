<?php

namespace App\Http\Controllers;

use App\Models\Ave;
use App\Models\TipoAve;
use App\Models\Variacao;
use App\Models\Lote;
use App\Models\Incubacao;
use App\Models\Morte;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\File;
use Intervention\Image\Laravel\Facades\Image;
use Illuminate\Support\Str;

class AveController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $aves = Ave::with(['tipoAve', 'variacao', 'lote', 'incubacao', 'morte'])->get();
        return view('aves.listar', compact('aves'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $tiposAves = TipoAve::all();
        $variacoes = Variacao::all();
        $lotes = Lote::all();
        $incubacoes = Incubacao::all();
        return view('aves.criar', compact('tiposAves', 'variacoes', 'lotes', 'incubacoes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'matricula' => 'required|string|max:255|unique:aves,matricula',
            'tipo_ave_id' => 'required|exists:tipos_aves,id',
            'variacao_id' => 'nullable|exists:variacoes,id',
            'lote_id' => 'nullable|exists:lotes,id',
            'incubacao_id' => 'nullable|exists:incubacoes,id',
            'data_eclosao' => 'required|date',
            'sexo' => 'nullable|string|in:Macho,Femea,Nao identificado',
            'vendavel' => 'boolean',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:5120',
        ]);

        $ave = new Ave($validated);
        $ave->vendavel = $request->has('vendavel');
        
        if ($request->hasFile('foto')) {
            $image = $request->file('foto');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('aves_fotos'); 

            if (!File::exists($destinationPath)) {
                File::makeDirectory($destinationPath, 0755, true);
            }

            $img = Image::read($image->getRealPath()); 
            $img->resize(500, 500, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            })->save($destinationPath . '/' . $filename, 80);
            $ave->foto_path = 'aves_fotos/' . $filename; 
        }

        $ave->save();

        return redirect()->route('aves.index')->with('success', 'Ave adicionada com sucesso!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Ave $ave)
    {
        // Carrega as relações aninhadas para obter informações de hereditariedade
        $ave->load([
            'tipoAve',
            'variacao',
            'lote',
            'incubacao.posturaOvo.acasalamento.macho', // Carrega macho através da incubação -> posturaOvo -> acasalamento
            'incubacao.posturaOvo.acasalamento.femea', // Carrega femea através da incubação -> posturaOvo -> acasalamento
            'morte'
        ]);
        return view('aves.ficha', compact('ave'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Ave $ave) // Usando Model Binding
    {
        if (!$ave) { 
            return redirect()->route('aves.index')->with('error', 'Ave não encontrada.');
        }

        $tiposAves = TipoAve::all();
        $variacoes = Variacao::all();
        $lotes = Lote::all();
        $incubacoes = Incubacao::all();
        return view('aves.editar', compact('ave', 'tiposAves', 'variacoes', 'lotes', 'incubacoes'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Ave $ave)
    {
        $validated = $request->validate([
            'matricula' => ['required', 'string', 'max:255', Rule::unique('aves')->ignore($ave->id)],
            'tipo_ave_id' => 'required|exists:tipos_aves,id',
            'variacao_id' => 'nullable|exists:variacoes,id',
            'lote_id' => 'nullable|exists:lotes,id',
            'incubacao_id' => 'nullable|exists:incubacoes,id',
            'data_eclosao' => 'required|date',
            'sexo' => 'nullable|string|in:Macho,Femea,Nao identificado',
            'vendavel' => 'boolean',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:5120',
        ]);

        if ($request->has('remover_foto_atual') && $request->input('remover_foto_atual') == '1') {
            if ($ave->foto_path && File::exists(public_path($ave->foto_path))) {
                File::delete(public_path($ave->foto_path));
                $ave->foto_path = null;
            }
        }

        if ($request->hasFile('foto')) {
            if ($ave->foto_path && File::exists(public_path($ave->foto_path))) {
                File::delete(public_path($ave->foto_path));
            }

            $image = $request->file('foto');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('aves_fotos');

            if (!File::exists($destinationPath)) {
                File::makeDirectory($destinationPath, 0755, true);
            }

            $img = Image::read($image->getRealPath());
            $img->resize(500, 500, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            })->save($destinationPath . '/' . $filename, 80);

            $ave->foto_path = 'aves_fotos/' . $filename;
        }

        $ave->fill($validated);
        $ave->vendavel = $request->has('vendavel');
        
        $ave->save();

        return redirect()->route('aves.index')->with('success', 'Ave atualizada com sucesso!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Ave $ave)
    {
        if ($ave->foto_path && File::exists(public_path($ave->foto_path))) {
            File::delete(public_path($ave->foto_path));
        }

        $ave->delete();

        return redirect()->route('aves.index')->with('success', 'Ave excluída com sucesso!');
    }

    /**
     * Show the form to register the death of an ave.
     */
    public function registerDeath(Ave $ave)
    {
        if ($ave->morte) {
            return redirect()->route('aves.show', $ave->id)->with('error', 'Esta ave já tem um registro de morte.');
        }

        return view('aves.registrar_morte', compact('ave'));
    }

    /**
     * Store the death details for an ave.
     */
    public function storeDeath(Request $request, Ave $ave)
    {
        $validated = $request->validate([
            'data_morte' => 'required|date',
            'causa' => 'nullable|string|max:255',
            'observacoes' => 'nullable|string',
        ]);

        $morte = new Morte($validated);
        $morte->ave_id = $ave->id;
        $morte->save();

        return redirect()->route('aves.index')->with('success', 'Morte da ave registrada com sucesso!');
    }

    /**
     * Busca sugestões de aves para autocompletar.
     */
    public function searchSuggestions(Request $request)
    {
        $termo = $request->query('termo');

        if (empty($termo)) {
            return response()->json([]);
        }

        $sugestoes = Ave::with('tipoAve')
                        ->where('id', 'LIKE', '%' . $termo . '%')
                        ->orWhere('matricula', 'LIKE', '%' . $termo . '%')
                        ->orWhereHas('tipoAve', function ($query) use ($termo) {
                            $query->where('nome', 'LIKE', '%' . $termo . '%');
                        })
                        ->limit(10)
                        ->get(['id', 'matricula', 'tipo_ave_id']);

        $formattedSugestoes = $sugestoes->map(function ($ave) {
            return [
                'id' => $ave->id,
                'matricula' => $ave->matricula,
                'tipo_ave_nome' => $ave->tipoAve->nome ?? 'N/A',
            ];
        });

        return response()->json($formattedSugestoes);
    }

    /**
     * Realiza a pesquisa completa de aves.
     */
    public function search(Request $request)
    {
        $termo = $request->query('termo_pesquisa');

        if (empty($termo)) {
            return redirect()->route('aves.index');
        }

        $aves = Ave::with(['tipoAve', 'lote', 'incubacao', 'morte', 'variacao'])
                    ->where('matricula', 'LIKE', '%' . $termo . '%')
                    ->orWhereHas('tipoAve', function ($query) use ($termo) {
                        $query->where('nome', 'LIKE', '%' . $termo . '%');
                    })
                    ->orWhereHas('variacao', function ($query) use ($termo) {
                        $query->where('nome', 'LIKE', '%' . $termo . '%');
                    })
                    ->orWhere('id', 'LIKE', '%' . $termo . '%')
                    ->get();

        return view('aves.listar', compact('aves'));
    }

    /**
     * Gera e armazena um código de validação para a certidão da ave.
     * Se já existir, redireciona para a certidão existente.
     */
    public function expedirCertidao(Ave $ave)
    {
        // Se a ave já tem um código de validação, redireciona para a certidão existente
        if ($ave->validation_code) {
            return redirect()->route('certidao.show', ['validation_code' => $ave->validation_code]);
        }

        // Gera um UUID (Universally Unique Identifier)
        $validationCode = (string) Str::uuid();

        // Armazena o código na ave
        $ave->validation_code = $validationCode;
        $ave->save();

        // Redireciona para a rota pública da certidão
        return redirect()->route('certidao.show', ['validation_code' => $validationCode])
                         ->with('success', 'Certidão expedida com sucesso!');
    }

    /**
     * Exibe a certidão de registro da ave publicamente.
     *
     * @param string $validation_code O código de validação da certidão.
     * @return \Illuminate\View\View|\Illuminate\Http\RedirectResponse
     */
    public function showCertidaoPublica(string $validation_code)
    {
        // Busca a ave pelo código de validação
        $ave = Ave::where('validation_code', $validation_code)
                  ->with(['tipoAve', 'variacao', 'lote', 'incubacao.loteOvos', 'morte'])
                  ->first();

        if (!$ave) {
            // Se a ave não for encontrada, redireciona com erro ou exibe uma página 404
            return redirect('/')->with('error', 'Certidão não encontrada ou código de validação inválido.');
        }

        // Retorna a view da certidão, passando os dados da ave
        return view('certidao.show', compact('ave'));
    }
}
