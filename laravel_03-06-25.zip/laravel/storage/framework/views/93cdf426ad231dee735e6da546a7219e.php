<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(url('/')); ?>" class="nav-link">Inicial</a> 
        </li>
    </ul>

    <form class="form-inline ml-3" action="<?php echo e(route('aves.search')); ?>"> 
        <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="search" placeholder="Buscar Ave" aria-label="Buscar" name="termo_pesquisa" id="search-input-aves"> 
            <ul id="suggestions-box"></ul>
            <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
    </form>
    
    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="far fa-bell"></i>
                <span class="badge badge-warning navbar-badge">15</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <span class="dropdown-header">15 Notifications</span>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fas fa-envelope mr-2"></i> 4 new messages
                    <span class="float-right text-muted text-sm">3 mins</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fas fa-users mr-2"></i> 8 friend requests
                    <span class="float-right text-muted text-sm">12 hours</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fas fa-file mr-2"></i> 3 new reports
                    <span class="float-right text-muted text-sm">2 days</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button"><i
                    class="fas fa-th-large"></i></a>
        </li>
    </ul>
</nav>

<style>
    .input-group-sm { /* Adicione esta classe para o container do input */
        position: relative;
    }

    #suggestions-box {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        width: 100%; /* Largura igual à do pai */
        background-color: #f9f9f9;
        border: 1px solid #ccc;
        border-top: none;
        z-index: 1000;
        list-style-type: none;
        padding: 0;
        margin: 0;
        display: none; /* Inicialmente escondido */
        box-sizing: border-box; /* Inclui borda e padding na largura */
    }

    #suggestions-box li {
        padding: 8px 12px;
        cursor: pointer;
    }

    #suggestions-box li:hover {
        background-color: #e9e9e9;
    }
</style>

<script>
    // Alterado para usar o ID 'search-input-aves'
    const searchInput = document.getElementById('search-input-aves');
    const suggestionsBox = document.getElementById('suggestions-box');
    const searchForm = searchInput.closest('form');

    searchInput.addEventListener('keyup', function() {
        const termo = this.value.trim();

        if (termo.length >= 3) { // Alterado para 3 caracteres
            // Usando a rota nomeada do Laravel para a URL da API de sugestões
            fetch('<?php echo e(route('aves.searchSuggestions')); ?>?termo=' + encodeURIComponent(termo))
                .then(response => response.json())
                .then(data => {
                    console.log("Dados recebidos:", data); // Verifique os dados recebidos
                    suggestionsBox.innerHTML = ''; // Limpar sugestões anteriores
                    if (data.length > 0) {
                        data.forEach(suggestion => {
                            console.log("Sugestão:", suggestion); // Verifique cada sugestão
                            const li = document.createElement('li');
                            // Certifique-se de que suggestion.tipo_ave_nome existe no JSON retornado
                            li.textContent = `${suggestion.matricula} - ${suggestion.tipo_ave_nome || 'N/A'} (ID: ${suggestion.id})`;
                            li.addEventListener('click', function() {
                                // CORRIGIDO: Usando 'ave' como nome do parâmetro para aves.show
                                window.location.href = '<?php echo e(route('aves.show', ['ave' => 'PLACEHOLDER_ID'])); ?>'.replace('PLACEHOLDER_ID', suggestion.id);
                            });
                            suggestionsBox.appendChild(li);
                        });
                        suggestionsBox.style.display = 'block';
                    } else {
                        suggestionsBox.style.display = 'none';
                    }
                });
        } else {
            suggestionsBox.style.display = 'none';
        }
    });

    // Lidar com a submissão do formulário padrão (pesquisa completa)
    searchForm.addEventListener('submit', function(event) {
        if (suggestionsBox.style.display === 'block') {
            event.preventDefault(); // Evitar a submissão padrão se as sugestões estiverem visíveis
            // O clique em uma sugestão já redireciona.
        }
    });

    // Esconder as sugestões ao clicar fora do input e da caixa de sugestões
    document.addEventListener('click', function(event) {
        if (!searchInput.contains(event.target) && !suggestionsBox.contains(event.target)) {
            suggestionsBox.style.display = 'none';
        }
    });
</script>
<?php /**PATH /home/cpetersenjr.com/httpdocs/laravel/resources/views/layouts/partials/navbar.blade.php ENDPATH**/ ?>