<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        Sistema de Criatório
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?>.</strong> Todos os direitos reservados.
</footer>
<aside class="control-sidebar control-sidebar-dark">
    </aside>
</div>
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="https://adminlte.io/themes/v3/plugins/jquery-ui/jquery-ui.min.js"></script>
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="https://adminlte.io/themes/v3/plugins/chart.js/Chart.min.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/sparklines/sparkline.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/moment/moment.min.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/daterangepicker/daterangepicker.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/summernote/summernote-bs4.min.js"></script>
<script src="https://adminlte.io/themes/v3/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="https://adminlte.io/themes/v3/dist/js/adminlte.js?v=3.2.0"></script>

<script src="https://adminlte.io/themes/v3/dist/js/pages/dashboard.js"></script>


<?php /**PATH /home/cpetersenjr.com/httpdocs/laravel/resources/views/layouts/partials/footer.blade.php ENDPATH**/ ?>