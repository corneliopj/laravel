<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?php echo e(route('aves.index')); ?>" class="brand-link"> 
      <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8"> 
      <span class="brand-text font-weight-light">Criatório Coroné</span>
    </a>

    <div class="sidebar">
      <?php if(auth()->guard()->check()): ?> 
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          
          <img src="<?php echo e(asset('img/'.Auth::user()->id.'.png')); ?>" class="img-circle elevation-2" alt="User Image" onerror="this.onerror=null;this.src='<?php echo e(asset('img/default-user.png')); ?>';"> 
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a> 
        </div>
      </div>
      <?php endif; ?>

      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          
          <li class="nav-item">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link"> 
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Painel de Controle
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link"> 
              <i class="nav-icon fas fa-brands fa-earlybirds"></i>
              <p>
                AVES
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('aves.index')); ?>" class="nav-link">
                  <i class="fas fa-list nav-icon"></i> 
                  <p>Listar</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('aves.create')); ?>" class="nav-link">
                  <i class="fas fa-plus nav-icon"></i> 
                  <p>Adicionar</p>
                </a>
              </li>
              <li class="nav-item"> 
                <a href="<?php echo e(route('tipos_aves.index')); ?>" class="nav-link">
                  <i class="fas fa-tags nav-icon"></i> 
                  <p>Tipos</p>
                </a>
              </li>
              <li class="nav-item"> 
                <a href="<?php echo e(route('acasalamentos.index')); ?>" class="nav-link">
                    <i class="fas fa-heart nav-icon"></i> 
                    <p>Acasalamentos</p>
                </a>
              </li>
              <li class="nav-item"> 
                <a href="<?php echo e(route('posturas_ovos.index')); ?>" class="nav-link">
                  <i class="fas fa-egg nav-icon"></i> 
                  <p>Posturas de Ovos</p>
                </a>
              </li>
              <li class="nav-item"> 
                <a href="<?php echo e(route('incubacoes.index')); ?>" class="nav-link">
                  <i class="fas fa-egg nav-icon"></i> 
                  <p>Incubações</p>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="<?php echo e(route('variacoes.index')); ?>" class="nav-link">
                  <i class="fas fa-palette nav-icon"></i> 
                  <p>Variações</p>
                </a>
              </li>
            </ul>
          </li>
        
          <li class="nav-item">
            <a href="#" class="nav-link"> 
                <i class="nav-icon fas fa-boxes"></i>
                <p>
                    LOTES
                    <i class="right fas fa-angle-left"></i>
                </p>
            </a>
            <ul class="nav nav-treeview">
                <li class="nav-item">
                    <a href="<?php echo e(route('lotes.index')); ?>" class="nav-link">
                        <i class="fas fa-list nav-icon"></i> 
                        <p>Listar</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('lotes.create')); ?>" class="nav-link">
                        <i class="fas fa-plus nav-icon"></i> 
                        <p>Adicionar</p>
                    </a>
                </li>
            </ul>
          </li>
          
          <li class="nav-header">FINANCEIRO</li>
          <li class="nav-item">
            <a href="#" class="nav-link"> 
              <i class="nav-icon fas fa-money-bill-wave"></i> 
              <p>
                Receitas
                <span class="badge badge-info right">2</span>
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link"> 
              <i class="nav-icon fas fa-money-bill-wave-alt"></i> 
              <p>
                Despesas
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link"> 
              <i class="nav-icon fas fa-chart-bar"></i> 
              <p>
                Relatórios
              </p>
            </a>
          </li>

          
          <?php if(auth()->guard()->check()): ?> 
          <li class="nav-header">AUTENTICAÇÃO</li>
          <li class="nav-item">
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Sair
              </p>
            </a>
          </li>
          <?php endif; ?>
          </ul>
      </nav>
      </div>
    </aside>
<?php /**PATH /home/cpetersenjr.com/httpdocs/laravel/resources/views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>