<?php
    $pageTitle = 'Editar Incubação';
?>


<?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="wrapper">
    
    <?php echo $__env->make('layouts.partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->make('layouts.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content-wrapper px-4 py-2" style="min-height:797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Editar Incubação</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('incubacoes.index')); ?>">Incubações</a></li>
                            <li class="breadcrumb-item active">Editar</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8"> 
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Dados da Incubação</h3>
                            </div>
                            <form action="<?php echo e(route('incubacoes.update', $incubacao->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field('PUT'); ?> 
                                <div class="card-body">
                                    
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    <?php endif; ?>

                                    <input type="hidden" name="id" id="id" value="<?php echo e(old('id', $incubacao->id)); ?>">
                                    <div class="form-group">
                                        <label for="lote_ovos_id">Lote de Ovos (Opcional)</label>
                                        <select name="lote_ovos_id" id="lote_ovos_id" class="form-control <?php $__errorArgs = ['lote_ovos_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">-- Selecione um Lote --</option>
                                            <?php $__currentLoopData = $lotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($lote->id); ?>" <?php echo e(old('lote_ovos_id', $incubacao->lote_ovos_id) == $lote->id ? 'selected' : ''); ?>>
                                                    <?php echo e($lote->identificacao_lote); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['lote_ovos_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    
                                    <div class="form-group">
                                        <label for="tipo_ave_id">Tipo de Ave</label>
                                        <select name="tipo_ave_id" id="tipo_ave_id" class="form-control <?php $__errorArgs = ['tipo_ave_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">-- Selecione o Tipo de Ave --</option>
                                            <?php $__currentLoopData = $tiposAves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tipo->id); ?>" data-tempo-eclosao="<?php echo e($tipo->tempo_eclosao); ?>" <?php echo e(old('tipo_ave_id', $incubacao->tipo_ave_id) == $tipo->id ? 'selected' : ''); ?>>
                                                    <?php echo e($tipo->nome); ?> (<?php echo e($tipo->tempo_eclosao ?? 'N/A'); ?> dias)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['tipo_ave_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="data_entrada_incubadora">Data de Entrada na Incubadora</label>
                                        <input type="date" name="data_entrada_incubadora" class="form-control <?php $__errorArgs = ['data_entrada_incubadora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_entrada_incubadora" value="<?php echo e(old('data_entrada_incubadora', $incubacao->data_entrada_incubadora->format('Y-m-d'))); ?>" required>
                                        <?php $__errorArgs = ['data_entrada_incubadora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="data_prevista_eclosao">Data Prevista de Eclosão</label>
                                        <input type="date" name="data_prevista_eclosao" class="form-control <?php $__errorArgs = ['data_prevista_eclosao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_prevista_eclosao" value="<?php echo e(old('data_prevista_eclosao', $incubacao->data_prevista_eclosao->format('Y-m-d'))); ?>" readonly> 
                                        <?php $__errorArgs = ['data_prevista_eclosao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="quantidade_ovos">Quantidade de Ovos</label>
                                        <input type="number" name="quantidade_ovos" class="form-control <?php $__errorArgs = ['quantidade_ovos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="quantidade_ovos" placeholder="Ex: 10" value="<?php echo e(old('quantidade_ovos', $incubacao->quantidade_ovos)); ?>" min="1" required>
                                        <?php $__errorArgs = ['quantidade_ovos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="quantidade_eclodidos">Quantidade de Eclodidos (Opcional)</label>
                                        <input type="number" name="quantidade_eclodidos" class="form-control <?php $__errorArgs = ['quantidade_eclodidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="quantidade_eclodidos" placeholder="Ex: 8" value="<?php echo e(old('quantidade_eclodidos', $incubacao->quantidade_eclodidos)); ?>" min="0">
                                        <?php $__errorArgs = ['quantidade_eclodidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="observacoes">Observações (Opcional)</label>
                                        <textarea name="observacoes" class="form-control <?php $__errorArgs = ['observacoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="observacoes" rows="3"><?php echo e(old('observacoes', $incubacao->observacoes)); ?></textarea>
                                        <?php $__errorArgs = ['observacoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="ativo" name="ativo" value="1" <?php echo e(old('ativo', $incubacao->ativo) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="ativo">Ativo</label>
                                            <small class="form-text text-muted">Marque se esta incubação está ativa.</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                                    <a href="<?php echo e(route('incubacoes.index')); ?>" class="btn btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dataEntradaInput = document.getElementById('data_entrada_incubadora');
            const tipoAveSelect = document.getElementById('tipo_ave_id');
            const dataPrevistaEclosaoInput = document.getElementById('data_prevista_eclosao');

            function calcularDataPrevistaEclosao() {
                const dataEntradaStr = dataEntradaInput.value;
                const selectedOption = tipoAveSelect.options[tipoAveSelect.selectedIndex];
                // Verifica se selectedOption existe e se dataset.tempoEclosao está definido
                const tempoEclosao = selectedOption && selectedOption.dataset.tempoEclosao ? parseInt(selectedOption.dataset.tempoEclosao) : NaN;

                if (dataEntradaStr && !isNaN(tempoEclosao)) {
                    const dataEntrada = new Date(dataEntradaStr + 'T00:00:00'); // Adiciona 'T00:00:00' para evitar problemas de fuso horário
                    if (!isNaN(dataEntrada.getTime())) { // Verifica se a data é válida
                        dataEntrada.setDate(dataEntrada.getDate() + tempoEclosao);
                        const ano = dataEntrada.getFullYear();
                        const mes = String(dataEntrada.getMonth() + 1).padStart(2, '0');
                        const dia = String(dataEntrada.getDate()).padStart(2, '0');
                        dataPrevistaEclosaoInput.value = `${ano}-${mes}-${dia}`;
                    } else {
                        dataPrevistaEclosaoInput.value = ''; // Limpa se a data de entrada for inválida
                    }
                } else {
                    dataPrevistaEclosaoInput.value = ''; // Limpa se data ou tempo de eclosão não estiverem disponíveis
                }
            }

            // Adiciona ouvintes de evento
            dataEntradaInput.addEventListener('change', calcularDataPrevistaEclosao);
            tipoAveSelect.addEventListener('change', calcularDataPrevistaEclosao);

            // Chama a função uma vez ao carregar a página para pré-preencher com os valores existentes
            calcularDataPrevistaEclosao();
        });
    </script>
</div>
<?php /**PATH /home/cpetersenjr.com/httpdocs/laravel/resources/views/incubacoes/editar.blade.php ENDPATH**/ ?>