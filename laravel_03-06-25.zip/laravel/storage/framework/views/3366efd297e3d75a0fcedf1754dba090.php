<?php
    $pageTitle = 'Detalhes da Ave';
?>


<?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="wrapper">
    
    <?php echo $__env->make('layouts.partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->make('layouts.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content-wrapper px-4 py-2" style="min-height: 797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($ave->matricula ?? 'Ave Desconhecida'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('aves.index')); ?>">Aves</a></li>
                            <li class="breadcrumb-item active">Detalhes</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações Gerais</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <dt class="col-sm-4">ID:</dt>
                                    <dd class="col-sm-8"><?php echo e($ave->id ?? ''); ?></dd>
                                    <dt class="col-sm-4">Matrícula:</dt>
                                    <dd class="col-sm-8"><?php echo e($ave->matricula ?? ''); ?></dd>
                                    <dt class="col-sm-4">Tipo:</dt>
                                    <dd class="col-sm-8"><?php echo e($ave->tipoAve->nome ?? ''); ?></dd>
                                    <dt class="col-sm-4">Variação:</dt>
                                    <dd class="col-sm-8"><?php echo e($ave->variacao->nome ?? 'N/A'); ?></dd>
                                    <dt class="col-sm-4">Sexo:</dt>
                                    <dd class="col-sm-8"><?php echo e($ave->sexo ?? ''); ?></dd>
                                    <dt class="col-sm-4">Data de Eclosão:</dt>
                                    <dd class="col-sm-8"><?php echo e($ave->data_eclosao ? $ave->data_eclosao->format('d/m/Y') : ''); ?></dd>
                                    <dt class="col-sm-4">Vendável:</dt>
                                    <dd class="col-sm-8"><?php echo e(($ave->vendavel ?? 0) ? 'Sim' : 'Não'); ?></dd>
                                    <dt class="col-sm-4">Data de Cadastro:</dt>
                                    <dd class="col-sm-8"><?php echo e($ave->created_at ? $ave->created_at->format('d/m/Y H:i:s') : ''); ?></dd>
                                </dl>
                                
                                <div class="mt-3">
                                    <?php if($ave->validation_code): ?>
                                        <a href="<?php echo e(route('certidao.show', ['validation_code' => $ave->validation_code])); ?>" target="_blank" class="btn btn-info">
                                            <i class="fas fa-file-alt"></i> Ver Certidão
                                        </a>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('aves.expedirCertidao', $ave->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success">
                                                <i class="fas fa-certificate"></i> Expedir Certidão
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações Adicionais</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <dt class="col-sm-4">Lote:</dt>
                                    <dd class="col-sm-8">
                                        <?php echo e($ave->lote->identificacao_lote ?? ''); ?>

                                        <?php if($ave->lote && $ave->lote->observacoes): ?>
                                            <br>Observação: <?php echo e($ave->lote->observacoes); ?>

                                        <?php endif; ?>
                                    </dd>
                                    <dt class="col-sm-4">Incubação:</dt>
                                    <dd class="col-sm-8">
                                        <?php if($ave->incubacao): ?>
                                            <span class="info-trigger" data-type="incubacao" data-id="<?php echo e($ave->incubacao->id); ?>">
                                                ID: <?php echo e($ave->incubacao->id); ?>

                                            </span>
                                            <br>Lote Ovos: <?php echo e($ave->incubacao->loteOvos->identificacao_lote ?? 'N/A'); ?>

                                            <br>Entrada: <?php echo e($ave->incubacao->data_entrada_incubadora->format('d/m/Y') ?? 'N/A'); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </dd>
                                </dl>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Hereditariedade</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <?php if($ave->incubacao && $ave->incubacao->posturaOvo && $ave->incubacao->posturaOvo->acasalamento): ?>
                                        <?php
                                            $acasalamento = $ave->incubacao->posturaOvo->acasalamento;
                                            $macho = $acasalamento->macho;
                                            $femea = $acasalamento->femea;
                                        ?>
                                        <dt class="col-sm-4">Pai:</dt>
                                        <dd class="col-sm-8">
                                            <?php if($macho): ?>
                                                <span class="info-trigger" data-type="ave" data-id="<?php echo e($macho->id); ?>">
                                                    <?php echo e($macho->matricula); ?>

                                                </span>
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </dd>
                                        <dt class="col-sm-4">Mãe:</dt>
                                        <dd class="col-sm-8">
                                            <?php if($femea): ?>
                                                <span class="info-trigger" data-type="ave" data-id="<?php echo e($femea->id); ?>">
                                                    <?php echo e($femea->matricula); ?>

                                                </span>
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </dd>
                                        <dt class="col-sm-4">Acasalamento:</dt>
                                        <dd class="col-sm-8">
                                            <span class="info-trigger" data-type="acasalamento" data-id="<?php echo e($acasalamento->id); ?>">
                                                ID: <?php echo e($acasalamento->id); ?>

                                            </span>
                                        </dd>
                                    <?php else: ?>
                                        <dd class="col-sm-12">Informações de hereditariedade não disponíveis.</dd>
                                    <?php endif; ?>
                                </dl>
                            </div>
                        </div>
                        
                        
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações de Morte</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <?php if($ave->morte): ?>
                                        <dt class="col-sm-4">Status:</dt>
                                        <dd class="col-sm-8"><span class="badge bg-secondary">Morreu</span></dd>
                                        <dt class="col-sm-4">Data da Morte:</dt>
                                        <dd class="col-sm-8"><?php echo e($ave->morte->data_morte ? $ave->morte->data_morte->format('d/m/Y') : 'N/A'); ?></dd>
                                        <dt class="col-sm-4">Causa:</dt>
                                        <dd class="col-sm-8"><?php echo e($ave->morte->causa ?? 'Não informada'); ?></dd>
                                        <dt class="col-sm-4">Observações:</dt>
                                        <dd class="col-sm-8"><?php echo e($ave->morte->observacoes ?? 'N/A'); ?></dd>
                                    <?php else: ?>
                                        <dt class="col-sm-4">Status:</dt>
                                        <dd class="col-sm-8"><span class="badge bg-success">Viva</span></dd>
                                    <?php endif; ?>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Foto da Ave</h3>
                            </div>
                            <div class="card-body text-center">
                                <?php if($ave->foto_path): ?>
                                    <img src="<?php echo e(asset($ave->foto_path)); ?>" alt="Foto da Ave" class="img-fluid" style="max-width: 500px; height: auto; border-radius: 8px;">
                                <?php else: ?>
                                    <p>Nenhuma foto disponível para esta ave.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div id="info-popup" class="card card-info" style="position: absolute; display: none; z-index: 1050; width: 300px; box-shadow: 0 0 10px rgba(0,0,0,0.2);">
        <div class="card-header">
            <h3 class="card-title" id="popup-title"></h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" id="close-popup"><i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body" id="popup-content">
            <!-- Conteúdo do popup será inserido aqui -->
        </div>
    </div>

    <style>
        .info-trigger {
            cursor: pointer;
            color: #007bff; /* Cor para indicar que é clicável/interativo */
            text-decoration: underline;
        }
        #info-popup {
            border-radius: 8px;
        }
        #info-popup .card-header {
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const infoTriggers = document.querySelectorAll('.info-trigger');
            const infoPopup = document.getElementById('info-popup');
            const popupTitle = document.getElementById('popup-title');
            const popupContent = document.getElementById('popup-content');
            const closePopupBtn = document.getElementById('close-popup');

            let currentTimeout;

            // Carrega os dados da ave e suas relações para o JavaScript de forma segura
            const aveData = <?php echo json_encode($ave, 15, 512) ?>;
            const incubacaoData = aveData.incubacao;
            const posturaOvoData = incubacaoData ? incubacaoData.postura_ovo : null;
            const acasalamentoData = posturaOvoData ? posturaOvoData.acasalamento : null;
            const machoData = acasalamentoData ? acasalamentoData.macho : null;
            const femeaData = acasalamentoData ? acasalamentoData.femea : null;

            infoTriggers.forEach(trigger => {
                trigger.addEventListener('mouseenter', function(event) {
                    clearTimeout(currentTimeout); // Limpa qualquer timeout anterior

                    const type = this.dataset.type;
                    const id = this.dataset.id;
                    let contentHTML = '';
                    let title = '';

                    // Posiciona o popup
                    infoPopup.style.left = (event.pageX + 15) + 'px';
                    infoPopup.style.top = (event.pageY + 15) + 'px';

                    // Preenche o conteúdo do popup com base no tipo e ID
                    if (type === 'incubacao') {
                        title = 'Detalhes da Incubação';
                        if (incubacaoData && incubacaoData.id == id) {
                            contentHTML = `
                                <strong>ID:</strong> ${incubacaoData.id}<br>
                                <strong>Lote Ovos:</strong> ${incubacaoData.lote_ovos ? incubacaoData.lote_ovos.identificacao_lote : 'N/A'}<br>
                                <strong>Data Entrada:</strong> ${new Date(incubacaoData.data_entrada_incubadora).toLocaleDateString('pt-BR')}<br>
                                <strong>Qtd. Ovos:</strong> ${incubacaoData.quantidade_ovos}<br>
                                <strong>Qtd. Eclodidos:</strong> ${incubacaoData.quantidade_eclodidos || 0}<br>
                                <strong>Observações:</strong> ${incubacaoData.observacoes || 'N/A'}
                            `;
                        } else {
                            contentHTML = 'Informações da incubação não encontradas.';
                        }
                    } else if (type === 'acasalamento') {
                        title = 'Detalhes do Acasalamento';
                        if (acasalamentoData && acasalamentoData.id == id) {
                            contentHTML = `
                                <strong>ID:</strong> ${acasalamentoData.id}<br>
                                <strong>Pai:</strong> ${machoData ? machoData.matricula : 'N/A'}<br>
                                <strong>Mãe:</strong> ${femeaData ? femeaData.matricula : 'N/A'}<br>
                                <strong>Início:</strong> ${new Date(acasalamentoData.data_inicio).toLocaleDateString('pt-BR')}<br>
                                <strong>Fim:</strong> ${acasalamentoData.data_fim ? new Date(acasalamentoData.data_fim).toLocaleDateString('pt-BR') : 'Em andamento'}<br>
                                <strong>Observações:</strong> ${acasalamentoData.observacoes || 'N/A'}
                            `;
                        } else {
                            contentHTML = 'Informações do acasalamento não encontradas.';
                        }
                    } else if (type === 'ave') {
                        title = 'Detalhes da Ave';
                        let targetAve = null;

                        if (id == aveData.id) { // Se for a própria ave
                            targetAve = aveData;
                        } else if (machoData && machoData.id == id) {
                            targetAve = machoData;
                        } else if (femeaData && femeaData.id == id) {
                            targetAve = femeaData;
                        }
                        
                        if (targetAve) {
                            contentHTML = `
                                <strong>ID:</strong> ${targetAve.id}<br>
                                <strong>Matrícula:</strong> ${targetAve.matricula}<br>
                                <strong>Tipo:</strong> ${targetAve.tipo_ave ? targetAve.tipo_ave.nome : 'N/A'}<br>
                                <strong>Sexo:</strong> ${targetAve.sexo}<br>
                                <strong>Data Eclosão:</strong> ${targetAve.data_eclosao ? new Date(targetAve.data_eclosao).toLocaleDateString('pt-BR') : 'N/A'}
                            `;
                        } else {
                            contentHTML = 'Informações da ave não encontradas.';
                        }
                    }

                    popupTitle.textContent = title;
                    popupContent.innerHTML = contentHTML;
                    infoPopup.style.display = 'block';
                });

                trigger.addEventListener('mouseleave', function() {
                    // Adiciona um pequeno atraso antes de esconder, para permitir que o mouse se mova para o popup
                    currentTimeout = setTimeout(() => {
                        infoPopup.style.display = 'none';
                    }, 200); // 200ms de atraso
                });
            });

            // Previne que o popup se esconda se o mouse entrar nele
            infoPopup.addEventListener('mouseenter', function() {
                clearTimeout(currentTimeout);
            });

            // Esconde o popup quando o mouse sair dele
            infoPopup.addEventListener('mouseleave', function() {
                infoPopup.style.display = 'none';
            });

            // Esconde o popup ao clicar no botão de fechar
            closePopupBtn.addEventListener('click', function() {
                infoPopup.style.display = 'none';
            });
        });
    </script>
</div>
<?php /**PATH /home/cpetersenjr.com/httpdocs/laravel/resources/views/aves/ficha.blade.php ENDPATH**/ ?>