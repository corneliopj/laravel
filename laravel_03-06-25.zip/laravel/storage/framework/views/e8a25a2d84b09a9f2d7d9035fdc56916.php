<?php
    $pageTitle = 'Listagem de Aves';
?>


<?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="wrapper">
    
    <?php echo $__env->make('layouts.partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->make('layouts.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="content-wrapper px-4 py-2" style="min-height:797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Listagem de Aves</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Aves</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>

                        
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e(session('error')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>

                        <div class="card-body">
                            
                            <div class="mb-3">
                                <a href="<?php echo e(route('aves.create')); ?>" class="btn btn-success">
                                    <i class="fas fa-plus"></i> Nova Ave
                                </a>
                            </div>

                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Matrícula</th>
                                        <th>Tipo de Ave</th>
                                        <th>Variação</th>
                                        <th>Lote</th>
                                        <th>Data Eclosão</th>
                                        <th>Sexo</th>
                                        <th>Vendável</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__empty_1 = true; $__currentLoopData = $aves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($ave->id); ?></td>
                                            <td><?php echo e($ave->matricula); ?></td>
                                            <td><?php echo e($ave->tipoAve->nome ?? 'N/A'); ?></td>
                                            <td><?php echo e($ave->variacao->nome ?? 'N/A'); ?></td>
                                            <td><?php echo e($ave->lote->identificacao_lote ?? 'N/A'); ?></td>
                                            <td><?php echo e($ave->data_eclosao->format('d/m/Y')); ?></td>
                                            <td><?php echo e($ave->sexo); ?></td>
                                            <td>
                                                <?php if($ave->vendavel): ?>
                                                    <span class="badge bg-success">Sim</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Não</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($ave->morte): ?>
                                                    <span class="badge bg-danger">Morto</span>
                                                <?php else: ?>
                                                    <span class="badge bg-info">Vivo</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('aves.show', $ave->id)); ?>" class="btn btn-sm btn-info" title="Ver Ficha">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('aves.edit', $ave->id)); ?>" class="btn btn-sm btn-primary" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <?php if(!$ave->morte): ?> 
                                                <a href="<?php echo e(route('aves.registerDeath', $ave->id)); ?>" class="btn btn-sm btn-warning" title="Registrar Morte">
                                                    <i class="fas fa-skull"></i>
                                                </a>
                                                <?php endif; ?>
                                                <form action="<?php echo e(route('aves.destroy', $ave->id)); ?>" method="POST" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Excluir" onclick="return confirm('Tem certeza que deseja excluir esta ave? Esta ação não pode ser desfeita.');">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="10">Nenhuma ave cadastrada.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php /**PATH /home/cpetersenjr.com/httpdocs/laravel/resources/views/aves/listar.blade.php ENDPATH**/ ?>