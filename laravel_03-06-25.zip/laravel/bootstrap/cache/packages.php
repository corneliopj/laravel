<?php return array (
  'intervention/image-laravel' => 
  array (
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Laravel\\Facades\\Image',
    ),
    'providers' => 
    array (
      0 => 'Intervention\\Image\\Laravel\\ServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
);