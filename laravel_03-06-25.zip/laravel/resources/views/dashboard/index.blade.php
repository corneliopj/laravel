@php
    $pageTitle = 'Dashboard';
@endphp

{{-- Inclui o partial head --}}
@include('layouts.partials.head')

<div class="wrapper">
    {{-- Inclui o partial navbar --}}
    @include('layouts.partials.navbar')
    {{-- Inclui o partial sidebar --}}
    @include('layouts.partials.sidebar')

    <div class="content-wrapper px-4 py-2" style="min-height:797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3>{{ $totalAvesAtivas }}</h3>
                                <p>Aves Ativas</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-earlybirds"></i>
                            </div>
                            <a href="{{ route('aves.index') }}" class="small-box-footer">Mais detalhes <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3>{{ $mortesUltimos30Dias }}</h3>
                                <p>Mortes (Últimos 30 Dias)</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-skull"></i>
                            </div>
                            <a href="{{ route('aves.index') }}" class="small-box-footer">Mais detalhes <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3>{{ $totalIncubacoesAtivas }}</h3>
                                <p>Incubações Ativas</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-egg"></i>
                            </div>
                            <a href="{{ route('incubacoes.index') }}" class="small-box-footer">Mais detalhes <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3>{{ $taxaEclosao }}<sup style="font-size: 20px">%</sup></h3>
                                <p>Taxa de Eclosão</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <a href="{{ route('incubacoes.index') }}" class="small-box-footer">Mais detalhes <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    </div>
                <div class="row">
                    <section class="col-lg-6 connectedSortable">
                        <div class="card card-primary card-outline">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-chart-pie mr-1"></i>
                                    Aves por Tipo
                                </h3>
                            </div>
                            <div class="card-body">
                                <canvas id="pieChartAvesPorTipo" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                            </div>
                            </div>
                        </section>
                    <section class="col-lg-6 connectedSortable">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-info-circle mr-1"></i>
                                    Resumo de Ovos e Eclodidos
                                </h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <dt class="col-sm-6">Total de Ovos Incubados:</dt>
                                    <dd class="col-sm-6">{{ $totalOvosIncubados }}</dd>
                                    <dt class="col-sm-6">Total de Aves Eclodidas:</dt>
                                    <dd class="col-sm-6">{{ $totalEclodidos }}</dd>
                                </dl>
                            </div>
                        </div>
                    </section>
                    </div>
                </div></section>
        </div>
    {{-- Inclui o partial footer --}}
    @include('layouts.partials.footer')
</div>

{{-- Script para o Gráfico de Pizza (Chart.js) --}}
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Dados passados do Laravel para o JavaScript
        const labels = @json($labelsAvesPorTipo);
        const data = @json($dataAvesPorTipo);

        // Cores dinâmicas para o gráfico de pizza
        const backgroundColors = [
            '#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de',
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'
        ];
        const hoverBackgroundColors = [
            '#e85e4c', '#008d4c', '#e08e0b', '#00acd6', '#357ca5', '#c2c7cb',
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'
        ];

        // Criação do gráfico de pizza
        const pieChartCanvas = document.getElementById('pieChartAvesPorTipo').getContext('2d');
        new Chart(pieChartCanvas, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColors.slice(0, labels.length), // Usa cores suficientes para os labels
                    hoverBackgroundColor: hoverBackgroundColors.slice(0, labels.length),
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                legend: {
                    display: true,
                    position: 'right', // Posição da legenda
                },
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            const dataset = data.datasets[tooltipItem.datasetIndex];
                            const total = dataset.data.reduce((previousValue, currentValue) => previousValue + currentValue);
                            const currentValue = dataset.data[tooltipItem.index];
                            const percentage = Math.floor(((currentValue / total) * 100) + 0.5);
                            return `${data.labels[tooltipItem.index]}: ${currentValue} (${percentage}%)`;
                        }
                    }
                }
            }
        });
    });
</script>
