@php
    $pageTitle = 'Detalhes da Ave';
@endphp

{{-- Inclui o partial head --}}
@include('layouts.partials.head')

<div class="wrapper">
    {{-- Inclui o partial navbar --}}
    @include('layouts.partials.navbar')
    {{-- Inclui o partial sidebar --}}
    @include('layouts.partials.sidebar')

    <div class="content-wrapper px-4 py-2" style="min-height: 797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">{{ $ave->matricula ?? 'Ave Desconhecida' }}</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ route('aves.index') }}">Aves</a></li>
                            <li class="breadcrumb-item active">Detalhes</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                {{-- Mensagens de sucesso/erro --}}
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        {{ session('error') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações Gerais</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <dt class="col-sm-4">ID:</dt>
                                    <dd class="col-sm-8">{{ $ave->id ?? '' }}</dd>
                                    <dt class="col-sm-4">Matrícula:</dt>
                                    <dd class="col-sm-8">{{ $ave->matricula ?? '' }}</dd>
                                    <dt class="col-sm-4">Tipo:</dt>
                                    <dd class="col-sm-8">{{ $ave->tipoAve->nome ?? '' }}</dd>
                                    <dt class="col-sm-4">Variação:</dt>
                                    <dd class="col-sm-8">{{ $ave->variacao->nome ?? 'N/A' }}</dd>
                                    <dt class="col-sm-4">Sexo:</dt>
                                    <dd class="col-sm-8">{{ $ave->sexo ?? '' }}</dd>
                                    <dt class="col-sm-4">Data de Eclosão:</dt>
                                    <dd class="col-sm-8">{{ $ave->data_eclosao ? $ave->data_eclosao->format('d/m/Y') : '' }}</dd>
                                    <dt class="col-sm-4">Vendável:</dt>
                                    <dd class="col-sm-8">{{ ($ave->vendavel ?? 0) ? 'Sim' : 'Não' }}</dd>
                                    <dt class="col-sm-4">Data de Cadastro:</dt>
                                    <dd class="col-sm-8">{{ $ave->created_at ? $ave->created_at->format('d/m/Y H:i:s') : '' }}</dd>
                                </dl>
                                {{-- Botão Expedir Certidão --}}
                                <div class="mt-3">
                                    @if ($ave->validation_code)
                                        <a href="{{ route('certidao.show', ['validation_code' => $ave->validation_code]) }}" target="_blank" class="btn btn-info">
                                            <i class="fas fa-file-alt"></i> Ver Certidão
                                        </a>
                                    @else
                                        <form action="{{ route('aves.expedirCertidao', $ave->id) }}" method="POST" style="display:inline;">
                                            @csrf
                                            <button type="submit" class="btn btn-success">
                                                <i class="fas fa-certificate"></i> Expedir Certidão
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações Adicionais</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <dt class="col-sm-4">Lote:</dt>
                                    <dd class="col-sm-8">
                                        {{ $ave->lote->identificacao_lote ?? '' }}
                                        @if($ave->lote && $ave->lote->observacoes)
                                            <br>Observação: {{ $ave->lote->observacoes }}
                                        @endif
                                    </dd>
                                    <dt class="col-sm-4">Incubação:</dt>
                                    <dd class="col-sm-8">
                                        @if($ave->incubacao)
                                            <span class="info-trigger" data-type="incubacao" data-id="{{ $ave->incubacao->id }}">
                                                ID: {{ $ave->incubacao->id }}
                                            </span>
                                            <br>Lote Ovos: {{ $ave->incubacao->loteOvos->identificacao_lote ?? 'N/A' }}
                                            <br>Entrada: {{ $ave->incubacao->data_entrada_incubadora->format('d/m/Y') ?? 'N/A' }}
                                        @else
                                            N/A
                                        @endif
                                    </dd>
                                </dl>
                            </div>
                        </div>
                        {{-- NOVO: Card de Hereditariedade --}}
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Hereditariedade</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    @if ($ave->incubacao && $ave->incubacao->posturaOvo && $ave->incubacao->posturaOvo->acasalamento)
                                        @php
                                            $acasalamento = $ave->incubacao->posturaOvo->acasalamento;
                                            $macho = $acasalamento->macho;
                                            $femea = $acasalamento->femea;
                                        @endphp
                                        <dt class="col-sm-4">Pai:</dt>
                                        <dd class="col-sm-8">
                                            @if ($macho)
                                                <span class="info-trigger" data-type="ave" data-id="{{ $macho->id }}">
                                                    {{ $macho->matricula }}
                                                </span>
                                            @else
                                                N/A
                                            @endif
                                        </dd>
                                        <dt class="col-sm-4">Mãe:</dt>
                                        <dd class="col-sm-8">
                                            @if ($femea)
                                                <span class="info-trigger" data-type="ave" data-id="{{ $femea->id }}">
                                                    {{ $femea->matricula }}
                                                </span>
                                            @else
                                                N/A
                                            @endif
                                        </dd>
                                        <dt class="col-sm-4">Acasalamento:</dt>
                                        <dd class="col-sm-8">
                                            <span class="info-trigger" data-type="acasalamento" data-id="{{ $acasalamento->id }}">
                                                ID: {{ $acasalamento->id }}
                                            </span>
                                        </dd>
                                    @else
                                        <dd class="col-sm-12">Informações de hereditariedade não disponíveis.</dd>
                                    @endif
                                </dl>
                            </div>
                        </div>
                        {{-- FIM NOVO: Card de Hereditariedade --}}
                        {{-- Card de Informações de Morte --}}
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações de Morte</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    @if ($ave->morte)
                                        <dt class="col-sm-4">Status:</dt>
                                        <dd class="col-sm-8"><span class="badge bg-secondary">Morreu</span></dd>
                                        <dt class="col-sm-4">Data da Morte:</dt>
                                        <dd class="col-sm-8">{{ $ave->morte->data_morte ? $ave->morte->data_morte->format('d/m/Y') : 'N/A' }}</dd>
                                        <dt class="col-sm-4">Causa:</dt>
                                        <dd class="col-sm-8">{{ $ave->morte->causa ?? 'Não informada' }}</dd>
                                        <dt class="col-sm-4">Observações:</dt>
                                        <dd class="col-sm-8">{{ $ave->morte->observacoes ?? 'N/A' }}</dd>
                                    @else
                                        <dt class="col-sm-4">Status:</dt>
                                        <dd class="col-sm-8"><span class="badge bg-success">Viva</span></dd>
                                    @endif
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- Seção da Foto da Ave --}}
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Foto da Ave</h3>
                            </div>
                            <div class="card-body text-center">
                                @if ($ave->foto_path)
                                    <img src="{{ asset($ave->foto_path) }}" alt="Foto da Ave" class="img-fluid" style="max-width: 500px; height: auto; border-radius: 8px;">
                                @else
                                    <p>Nenhuma foto disponível para esta ave.</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Inclui o partial footer --}}
    @include('layouts.partials.footer')

    {{-- Popup / Tooltip HTML --}}
    <div id="info-popup" class="card card-info" style="position: absolute; display: none; z-index: 1050; width: 300px; box-shadow: 0 0 10px rgba(0,0,0,0.2);">
        <div class="card-header">
            <h3 class="card-title" id="popup-title"></h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" id="close-popup"><i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body" id="popup-content">
            <!-- Conteúdo do popup será inserido aqui -->
        </div>
    </div>

    <style>
        .info-trigger {
            cursor: pointer;
            color: #007bff; /* Cor para indicar que é clicável/interativo */
            text-decoration: underline;
        }
        #info-popup {
            border-radius: 8px;
        }
        #info-popup .card-header {
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const infoTriggers = document.querySelectorAll('.info-trigger');
            const infoPopup = document.getElementById('info-popup');
            const popupTitle = document.getElementById('popup-title');
            const popupContent = document.getElementById('popup-content');
            const closePopupBtn = document.getElementById('close-popup');

            let currentTimeout;

            // Carrega os dados da ave e suas relações para o JavaScript de forma segura
            const aveData = @json($ave);
            const incubacaoData = aveData.incubacao;
            const posturaOvoData = incubacaoData ? incubacaoData.postura_ovo : null;
            const acasalamentoData = posturaOvoData ? posturaOvoData.acasalamento : null;
            const machoData = acasalamentoData ? acasalamentoData.macho : null;
            const femeaData = acasalamentoData ? acasalamentoData.femea : null;

            infoTriggers.forEach(trigger => {
                trigger.addEventListener('mouseenter', function(event) {
                    clearTimeout(currentTimeout); // Limpa qualquer timeout anterior

                    const type = this.dataset.type;
                    const id = this.dataset.id;
                    let contentHTML = '';
                    let title = '';

                    // Posiciona o popup
                    infoPopup.style.left = (event.pageX + 15) + 'px';
                    infoPopup.style.top = (event.pageY + 15) + 'px';

                    // Preenche o conteúdo do popup com base no tipo e ID
                    if (type === 'incubacao') {
                        title = 'Detalhes da Incubação';
                        if (incubacaoData && incubacaoData.id == id) {
                            contentHTML = `
                                <strong>ID:</strong> ${incubacaoData.id}<br>
                                <strong>Lote Ovos:</strong> ${incubacaoData.lote_ovos ? incubacaoData.lote_ovos.identificacao_lote : 'N/A'}<br>
                                <strong>Data Entrada:</strong> ${new Date(incubacaoData.data_entrada_incubadora).toLocaleDateString('pt-BR')}<br>
                                <strong>Qtd. Ovos:</strong> ${incubacaoData.quantidade_ovos}<br>
                                <strong>Qtd. Eclodidos:</strong> ${incubacaoData.quantidade_eclodidos || 0}<br>
                                <strong>Observações:</strong> ${incubacaoData.observacoes || 'N/A'}
                            `;
                        } else {
                            contentHTML = 'Informações da incubação não encontradas.';
                        }
                    } else if (type === 'acasalamento') {
                        title = 'Detalhes do Acasalamento';
                        if (acasalamentoData && acasalamentoData.id == id) {
                            contentHTML = `
                                <strong>ID:</strong> ${acasalamentoData.id}<br>
                                <strong>Pai:</strong> ${machoData ? machoData.matricula : 'N/A'}<br>
                                <strong>Mãe:</strong> ${femeaData ? femeaData.matricula : 'N/A'}<br>
                                <strong>Início:</strong> ${new Date(acasalamentoData.data_inicio).toLocaleDateString('pt-BR')}<br>
                                <strong>Fim:</strong> ${acasalamentoData.data_fim ? new Date(acasalamentoData.data_fim).toLocaleDateString('pt-BR') : 'Em andamento'}<br>
                                <strong>Observações:</strong> ${acasalamentoData.observacoes || 'N/A'}
                            `;
                        } else {
                            contentHTML = 'Informações do acasalamento não encontradas.';
                        }
                    } else if (type === 'ave') {
                        title = 'Detalhes da Ave';
                        let targetAve = null;

                        if (id == aveData.id) { // Se for a própria ave
                            targetAve = aveData;
                        } else if (machoData && machoData.id == id) {
                            targetAve = machoData;
                        } else if (femeaData && femeaData.id == id) {
                            targetAve = femeaData;
                        }
                        
                        if (targetAve) {
                            contentHTML = `
                                <strong>ID:</strong> ${targetAve.id}<br>
                                <strong>Matrícula:</strong> ${targetAve.matricula}<br>
                                <strong>Tipo:</strong> ${targetAve.tipo_ave ? targetAve.tipo_ave.nome : 'N/A'}<br>
                                <strong>Sexo:</strong> ${targetAve.sexo}<br>
                                <strong>Data Eclosão:</strong> ${targetAve.data_eclosao ? new Date(targetAve.data_eclosao).toLocaleDateString('pt-BR') : 'N/A'}
                            `;
                        } else {
                            contentHTML = 'Informações da ave não encontradas.';
                        }
                    }

                    popupTitle.textContent = title;
                    popupContent.innerHTML = contentHTML;
                    infoPopup.style.display = 'block';
                });

                trigger.addEventListener('mouseleave', function() {
                    // Adiciona um pequeno atraso antes de esconder, para permitir que o mouse se mova para o popup
                    currentTimeout = setTimeout(() => {
                        infoPopup.style.display = 'none';
                    }, 200); // 200ms de atraso
                });
            });

            // Previne que o popup se esconda se o mouse entrar nele
            infoPopup.addEventListener('mouseenter', function() {
                clearTimeout(currentTimeout);
            });

            // Esconde o popup quando o mouse sair dele
            infoPopup.addEventListener('mouseleave', function() {
                infoPopup.style.display = 'none';
            });

            // Esconde o popup ao clicar no botão de fechar
            closePopupBtn.addEventListener('click', function() {
                infoPopup.style.display = 'none';
            });
        });
    </script>
</div>
