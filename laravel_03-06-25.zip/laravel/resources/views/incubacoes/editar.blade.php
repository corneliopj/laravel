@php
    $pageTitle = 'Editar Incubação';
@endphp

{{-- Inclui o partial head --}}
@include('layouts.partials.head')

<div class="wrapper">
    {{-- Inclui o partial navbar --}}
    @include('layouts.partials.navbar')
    {{-- Inclui o partial sidebar --}}
    @include('layouts.partials.sidebar')

    <div class="content-wrapper px-4 py-2" style="min-height:797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Editar Incubação</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('incubacoes.index') }}">Incubações</a></li>
                            <li class="breadcrumb-item active">Editar</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8"> {{-- Aumentando a largura do formulário --}}
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Dados da Incubação</h3>
                            </div>
                            <form action="{{ route('incubacoes.update', $incubacao->id) }}" method="POST">
                                @csrf {{-- Token CSRF para segurança --}}
                                @method('PUT') {{-- Método HTTP PUT para atualização RESTful --}}
                                <div class="card-body">
                                    {{-- Exibe mensagens de erro de validação do Laravel --}}
                                    @if ($errors->any())
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <ul>
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    @endif

                                    <input type="hidden" name="id" id="id" value="{{ old('id', $incubacao->id) }}">
                                    <div class="form-group">
                                        <label for="lote_ovos_id">Lote de Ovos (Opcional)</label>
                                        <select name="lote_ovos_id" id="lote_ovos_id" class="form-control @error('lote_ovos_id') is-invalid @enderror">
                                            <option value="">-- Selecione um Lote --</option>
                                            @foreach ($lotes as $lote)
                                                <option value="{{ $lote->id }}" {{ old('lote_ovos_id', $incubacao->lote_ovos_id) == $lote->id ? 'selected' : '' }}>
                                                    {{ $lote->identificacao_lote }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('lote_ovos_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>

                                    {{-- NOVO CAMPO: Tipo de Ave --}}
                                    <div class="form-group">
                                        <label for="tipo_ave_id">Tipo de Ave</label>
                                        <select name="tipo_ave_id" id="tipo_ave_id" class="form-control @error('tipo_ave_id') is-invalid @enderror" required>
                                            <option value="">-- Selecione o Tipo de Ave --</option>
                                            @foreach ($tiposAves as $tipo)
                                                <option value="{{ $tipo->id }}" data-tempo-eclosao="{{ $tipo->tempo_eclosao }}" {{ old('tipo_ave_id', $incubacao->tipo_ave_id) == $tipo->id ? 'selected' : '' }}>
                                                    {{ $tipo->nome }} ({{ $tipo->tempo_eclosao ?? 'N/A' }} dias)
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('tipo_ave_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="data_entrada_incubadora">Data de Entrada na Incubadora</label>
                                        <input type="date" name="data_entrada_incubadora" class="form-control @error('data_entrada_incubadora') is-invalid @enderror" id="data_entrada_incubadora" value="{{ old('data_entrada_incubadora', $incubacao->data_entrada_incubadora->format('Y-m-d')) }}" required>
                                        @error('data_entrada_incubadora')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="data_prevista_eclosao">Data Prevista de Eclosão</label>
                                        <input type="date" name="data_prevista_eclosao" class="form-control @error('data_prevista_eclosao') is-invalid @enderror" id="data_prevista_eclosao" value="{{ old('data_prevista_eclosao', $incubacao->data_prevista_eclosao->format('Y-m-d')) }}" readonly> {{-- Campo somente leitura --}}
                                        @error('data_prevista_eclosao')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="quantidade_ovos">Quantidade de Ovos</label>
                                        <input type="number" name="quantidade_ovos" class="form-control @error('quantidade_ovos') is-invalid @enderror" id="quantidade_ovos" placeholder="Ex: 10" value="{{ old('quantidade_ovos', $incubacao->quantidade_ovos) }}" min="1" required>
                                        @error('quantidade_ovos')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="quantidade_eclodidos">Quantidade de Eclodidos (Opcional)</label>
                                        <input type="number" name="quantidade_eclodidos" class="form-control @error('quantidade_eclodidos') is-invalid @enderror" id="quantidade_eclodidos" placeholder="Ex: 8" value="{{ old('quantidade_eclodidos', $incubacao->quantidade_eclodidos) }}" min="0">
                                        @error('quantidade_eclodidos')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="observacoes">Observações (Opcional)</label>
                                        <textarea name="observacoes" class="form-control @error('observacoes') is-invalid @enderror" id="observacoes" rows="3">{{ old('observacoes', $incubacao->observacoes) }}</textarea>
                                        @error('observacoes')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="ativo" name="ativo" value="1" {{ old('ativo', $incubacao->ativo) ? 'checked' : '' }}>
                                            <label class="form-check-label" for="ativo">Ativo</label>
                                            <small class="form-text text-muted">Marque se esta incubação está ativa.</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                                    <a href="{{ route('incubacoes.index') }}" class="btn btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Inclui o partial footer --}}
    @include('layouts.partials.footer')

    {{-- Script JavaScript para cálculo da data prevista de eclosão (igual ao criar.blade.php) --}}
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dataEntradaInput = document.getElementById('data_entrada_incubadora');
            const tipoAveSelect = document.getElementById('tipo_ave_id');
            const dataPrevistaEclosaoInput = document.getElementById('data_prevista_eclosao');

            function calcularDataPrevistaEclosao() {
                const dataEntradaStr = dataEntradaInput.value;
                const selectedOption = tipoAveSelect.options[tipoAveSelect.selectedIndex];
                // Verifica se selectedOption existe e se dataset.tempoEclosao está definido
                const tempoEclosao = selectedOption && selectedOption.dataset.tempoEclosao ? parseInt(selectedOption.dataset.tempoEclosao) : NaN;

                if (dataEntradaStr && !isNaN(tempoEclosao)) {
                    const dataEntrada = new Date(dataEntradaStr + 'T00:00:00'); // Adiciona 'T00:00:00' para evitar problemas de fuso horário
                    if (!isNaN(dataEntrada.getTime())) { // Verifica se a data é válida
                        dataEntrada.setDate(dataEntrada.getDate() + tempoEclosao);
                        const ano = dataEntrada.getFullYear();
                        const mes = String(dataEntrada.getMonth() + 1).padStart(2, '0');
                        const dia = String(dataEntrada.getDate()).padStart(2, '0');
                        dataPrevistaEclosaoInput.value = `${ano}-${mes}-${dia}`;
                    } else {
                        dataPrevistaEclosaoInput.value = ''; // Limpa se a data de entrada for inválida
                    }
                } else {
                    dataPrevistaEclosaoInput.value = ''; // Limpa se data ou tempo de eclosão não estiverem disponíveis
                }
            }

            // Adiciona ouvintes de evento
            dataEntradaInput.addEventListener('change', calcularDataPrevistaEclosao);
            tipoAveSelect.addEventListener('change', calcularDataPrevistaEclosao);

            // Chama a função uma vez ao carregar a página para pré-preencher com os valores existentes
            calcularDataPrevistaEclosao();
        });
    </script>
</div>
