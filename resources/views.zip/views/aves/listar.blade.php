@php
    $pageTitle = 'Listagem de Aves';
@endphp

{{-- Inclui o partial head --}}
@include('layouts.partials.head')

<div class="wrapper">
    {{-- Inclui o partial navbar --}}
    @include('layouts.partials.navbar')
    {{-- Inclui o partial sidebar --}}
    @include('layouts.partials.sidebar')

    <div class="content-wrapper px-4 py-2" style="min-height:797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Listagem de Aves</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                            <li class="breadcrumb-item active">Aves</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        {{-- Exibe mensagens de sucesso (flash) --}}
                        @if (session('success'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('success') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif

                        {{-- Exibe mensagens de erro (flash) --}}
                        @if (session('error'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif

                        <div class="card-body">
                            {{-- Botão Nova Ave --}}
                            <div class="mb-3">
                                <a href="{{ route('aves.create') }}" class="btn btn-success">
                                    <i class="fas fa-plus"></i> Nova Ave
                                </a>
                            </div>

                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Matrícula</th>
                                        <th>Tipo de Ave</th>
                                        <th>Variação</th>
                                        <th>Lote</th>
                                        <th>Data Eclosão</th>
                                        <th>Sexo</th>
                                        <th>Vendável</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {{-- Verifica se existem aves e itera sobre elas --}}
                                    @forelse ($aves as $ave)
                                        <tr>
                                            <td>{{ $ave->id }}</td>
                                            <td>{{ $ave->matricula }}</td>
                                            <td>{{ $ave->tipoAve->nome ?? 'N/A' }}</td>
                                            <td>{{ $ave->variacao->nome ?? 'N/A' }}</td>
                                            <td>{{ $ave->lote->identificacao_lote ?? 'N/A' }}</td>
                                            <td>{{ $ave->data_eclosao->format('d/m/Y') }}</td>
                                            <td>{{ $ave->sexo }}</td>
                                            <td>
                                                @if ($ave->vendavel)
                                                    <span class="badge bg-success">Sim</span>
                                                @else
                                                    <span class="badge bg-secondary">Não</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if ($ave->morte)
                                                    <span class="badge bg-danger">Morto</span>
                                                @else
                                                    <span class="badge bg-info">Vivo</span>
                                                @endif
                                            </td>
                                            <td>
                                                <a href="{{ route('aves.show', $ave->id) }}" class="btn btn-sm btn-info" title="Ver Ficha">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="{{ route('aves.edit', $ave->id) }}" class="btn btn-sm btn-primary" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                @if (!$ave->morte) {{-- Só mostra o botão de registrar morte se a ave não estiver morta --}}
                                                <a href="{{ route('aves.registerDeath', $ave->id) }}" class="btn btn-sm btn-warning" title="Registrar Morte">
                                                    <i class="fas fa-skull"></i>
                                                </a>
                                                @endif
                                                <form action="{{ route('aves.destroy', $ave->id) }}" method="POST" style="display:inline;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Excluir" onclick="return confirm('Tem certeza que deseja excluir esta ave? Esta ação não pode ser desfeita.');">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr><td colspan="10">Nenhuma ave cadastrada.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Inclui o partial footer --}}
    @include('layouts.partials.footer')
</div>
