@php
    $pageTitle = 'Detalhes da Ave';
@endphp

{{-- Inclui o partial head --}}
@include('layouts.partials.head')

<div class="wrapper">
    {{-- Inclui o partial navbar --}}
    @include('layouts.partials.navbar')
    {{-- Inclui o partial sidebar --}}
    @include('layouts.partials.sidebar')

    <div class="content-wrapper px-4 py-2" style="min-height: 797px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">{{ $ave->matricula ?? 'Ave Desconhecida' }}</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ route('aves.index') }}">Aves</a></li>
                            <li class="breadcrumb-item active">Detalhes</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                {{-- Mensagens de sucesso/erro --}}
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        {{ session('error') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações Gerais</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <dt class="col-sm-4">ID:</dt>
                                    <dd class="col-sm-8">{{ $ave->id ?? '' }}</dd>
                                    <dt class="col-sm-4">Matrícula:</dt>
                                    <dd class="col-sm-8">{{ $ave->matricula ?? '' }}</dd>
                                    <dt class="col-sm-4">Tipo:</dt>
                                    <dd class="col-sm-8">{{ $ave->tipoAve->nome ?? '' }}</dd>
                                    <dt class="col-sm-4">Variação:</dt>
                                    <dd class="col-sm-8">{{ $ave->variacao->nome ?? 'N/A' }}</dd>
                                    <dt class="col-sm-4">Sexo:</dt>
                                    <dd class="col-sm-8">{{ $ave->sexo ?? '' }}</dd>
                                    <dt class="col-sm-4">Data de Eclosão:</dt>
                                    <dd class="col-sm-8">{{ $ave->data_eclosao ? $ave->data_eclosao->format('d/m/Y') : '' }}</dd>
                                    <dt class="col-sm-4">Vendável:</dt>
                                    <dd class="col-sm-8">{{ ($ave->vendavel ?? 0) ? 'Sim' : 'Não' }}</dd>
                                    <dt class="col-sm-4">Data de Cadastro:</dt>
                                    <dd class="col-sm-8">{{ $ave->created_at ? $ave->created_at->format('d/m/Y H:i:s') : '' }}</dd>
                                </dl>
                                {{-- NOVO: Botão Expedir Certidão --}}
                                <div class="mt-3">
                                    @if ($ave->validation_code)
                                        <a href="{{ route('certidao.show', ['validation_code' => $ave->validation_code]) }}" target="_blank" class="btn btn-info">
                                            <i class="fas fa-file-alt"></i> Ver Certidão
                                        </a>
                                    @else
                                        <form action="{{ route('aves.expedirCertidao', $ave->id) }}" method="POST" style="display:inline;">
                                            @csrf
                                            <button type="submit" class="btn btn-success">
                                                <i class="fas fa-certificate"></i> Expedir Certidão
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações Adicionais</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    <dt class="col-sm-4">Lote:</dt>
                                    <dd class="col-sm-8">
                                        {{ $ave->lote->identificacao_lote ?? '' }}
                                        @if($ave->lote && $ave->lote->observacoes)
                                            <br>Observação: {{ $ave->lote->observacoes }}
                                        @endif
                                    </dd>
                                    <dt class="col-sm-4">Incubação:</dt>
                                    <dd class="col-sm-8">
                                        @if($ave->incubacao)
                                            Lote: {{ $ave->incubacao->loteOvos->identificacao_lote ?? 'N/A' }} - Entrada: {{ $ave->incubacao->data_entrada_incubadora->format('d/m/Y') ?? 'N/A' }}
                                        @else
                                            N/A
                                        @endif
                                    </dd>
                                </dl>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações de Morte</h3>
                            </div>
                            <div class="card-body">
                                <dl class="row">
                                    @if ($ave->morte)
                                        <dt class="col-sm-4">Status:</dt>
                                        <dd class="col-sm-8"><span class="badge bg-secondary">Morreu</span></dd>
                                        <dt class="col-sm-4">Data da Morte:</dt>
                                        <dd class="col-sm-8">{{ $ave->morte->data_morte ? $ave->morte->data_morte->format('d/m/Y') : 'N/A' }}</dd>
                                        <dt class="col-sm-4">Causa:</dt>
                                        <dd class="col-sm-8">{{ $ave->morte->causa ?? 'Não informada' }}</dd>
                                        <dt class="col-sm-4">Observações:</dt>
                                        <dd class="col-sm-8">{{ $ave->morte->observacoes ?? 'N/A' }}</dd>
                                    @else
                                        <dt class="col-sm-4">Status:</dt>
                                        <dd class="col-sm-8"><span class="badge bg-success">Viva</span></dd>
                                    @endif
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Foto da Ave</h3>
                            </div>
                            <div class="card-body text-center">
                                @if ($ave->foto_path)
                                    <img src="{{ asset($ave->foto_path) }}" alt="Foto da Ave" class="img-fluid" style="max-width: 500px; height: auto; border-radius: 8px;">
                                @else
                                    <p>Nenhuma foto disponível para esta ave.</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Inclui o partial footer --}}
    @include('layouts.partials.footer')
</div>
