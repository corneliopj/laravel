<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AdminLTE Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://getbootstrap.com/docs/5.3/examples/sidebars/sidebars.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="vendor/fontawesome-free/css/all.min.css">
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="vendor/admin-lte/css/adminlte.min.css">
	<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	
	<style>.bd-placeholder-img{font-size:1.125rem;text-anchor:middle;-webkit-user-select:none;-moz-user-select:none;user-select:none}@media (min-width: 768px){.bd-placeholder-img-lg{font-size:3.5rem}}.b-example-divider{width:100%;height:3rem;background-color:#0000001a;border:solid rgba(0,0,0,.15);border-width:1px 0;box-shadow:inset 0 .5em 1.5em #0000001a,inset 0 .125em .5em #00000026}.b-example-vr{flex-shrink:0;width:1.5rem;height:100vh}.bi{vertical-align:-.125em;fill:currentColor}.nav-scroller{position:relative;z-index:2;height:2.75rem;overflow-y:hidden}.nav-scroller .nav{display:flex;flex-wrap:nowrap;padding-bottom:1rem;margin-top:-1px;overflow-x:auto;text-align:center;white-space:nowrap;-webkit-overflow-scrolling:touch}.btn-bd-primary{--bd-violet-bg: #712cf9;--bd-violet-rgb: 112.520718, 44.062154, 249.437846;--bs-btn-font-weight: 600;--bs-btn-color: var(--bs-white);--bs-btn-bg: var(--bd-violet-bg);--bs-btn-border-color: var(--bd-violet-bg);--bs-btn-hover-color: var(--bs-white);--bs-btn-hover-bg: #6528e0;--bs-btn-hover-border-color: #6528e0;--bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);--bs-btn-active-color: var(--bs-btn-hover-color);--bs-btn-active-bg: #5a23c8;--bs-btn-active-border-color: #5a23c8}.bd-mode-toggle{z-index:1500}.bd-mode-toggle .bi{width:1em;height:1em}.bd-mode-toggle .dropdown-menu .active .bi{display:block!important}
</style>
	<style>@keyframes slide-in-one-tap {
  from {
    transform: translateY(80px);
  }
  to {
    transform: translateY(0px);
  }
}

.trust-hide-gracefully {
  opacity: 0;
}

.trust-wallet-one-tap .hidden {
    display: none;
  }

.trust-wallet-one-tap .semibold {
    font-weight: 500;
  }

.trust-wallet-one-tap .binance-plex {
    font-family: 'Binance';
  }

.trust-wallet-one-tap .rounded-full {
    border-radius: 50%;
  }

.trust-wallet-one-tap .flex {
    display: flex;
  }

.trust-wallet-one-tap .flex-col {
    flex-direction: column;
  }

.trust-wallet-one-tap .items-center {
    align-items: center;
  }

.trust-wallet-one-tap .space-between {
    justify-content: space-between;
  }

.trust-wallet-one-tap .justify-center {
    justify-content: center;
  }

.trust-wallet-one-tap .w-full {
    width: 100%;
  }

.trust-wallet-one-tap .box {
    transition: all 0.5s cubic-bezier(0, 0, 0, 1.43);
    animation: slide-in-one-tap 0.5s cubic-bezier(0, 0, 0, 1.43);
    width: 384px;
    border-radius: 15px;
    background: #fff;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.25);
    position: fixed;
    right: 30px;
    bottom: 30px;
    z-index: 1020;
  }

.trust-wallet-one-tap .header {
    gap: 15px;
    border-bottom: 1px solid #e6e6e6;
    padding: 10px 18px;
  }

.trust-wallet-one-tap .header .left-items {
      gap: 15px;
    }

.trust-wallet-one-tap .header .title {
      color: #1e2329;
      font-size: 18px;
      font-weight: 600;
      line-height: 28px;
    }

.trust-wallet-one-tap .header .subtitle {
      color: #474d57;
      font-size: 14px;
      line-height: 20px;
    }

.trust-wallet-one-tap .header .close {
      color: #1e2329;
      cursor: pointer;
    }

.trust-wallet-one-tap .body {
    padding: 9px 18px;
    gap: 10px;
  }

.trust-wallet-one-tap .body .right-items {
      gap: 10px;
      width: 100%;
    }

.trust-wallet-one-tap .body .right-items .wallet-title {
        color: #1e2329;
        font-size: 16px;
        font-weight: 600;
        line-height: 20px;
      }

.trust-wallet-one-tap .body .right-items .wallet-subtitle {
        color: #474d57;
        font-size: 14px;
        line-height: 20px;
      }

.trust-wallet-one-tap .connect-indicator {
    gap: 15px;
    padding: 8px 0;
  }

.trust-wallet-one-tap .connect-indicator .flow-icon {
      color: #474d57;
    }

.trust-wallet-one-tap .loading-color {
    color: #fff;
  }

.trust-wallet-one-tap .button {
    border-radius: 50px;
    outline: 2px solid transparent;
    outline-offset: 2px;
    background-color: rgb(5, 0, 255);
    border-color: rgb(229, 231, 235);
    cursor: pointer;
    text-align: center;
    height: 45px;
  }

.trust-wallet-one-tap .button .button-text {
      color: #fff;
      font-size: 16px;
      font-weight: 600;
      line-height: 20px;
    }

.trust-wallet-one-tap .footer {
    margin: 20px 30px;
  }

.trust-wallet-one-tap .check-icon {
    color: #fff;
  }

@font-face {
  font-family: 'Binance';
  src: url(chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Regular.otf) format('opentype');
  font-weight: 400;
  font-style: normal;
}

@font-face {
  font-family: 'Binance';
  src: url(chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Medium.otf) format('opentype');
  font-weight: 500;
  font-style: normal;
}

@font-face {
  font-family: 'Binance';
  src: url(chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-SemiBold.otf) format('opentype');
  font-weight: 600;
  font-style: normal;
}
</style>
	<style>@import"https://fonts.googleapis.com/css2?family=Rubik&display=swap";._button_1m1ep_1{all:unset;-webkit-appearance:unset;-moz-appearance:unset;appearance:unset;height:32px;display:flex;gap:6px;padding:6px 10px;border-radius:6px;color:#fff;font-size:12px;cursor:pointer;letter-spacing:.3px;line-height:16px;align-items:center;justify-content:center;width:91px;margin-bottom:-.5px;font-weight:600;background-color:#ea4b3a}._button_1m1ep_1:hover{filter:brightness(1.1)}._button__icon_1m1ep_24{font-size:14px}._button_1m1ep_1[disabled]{pointer-events:none;opacity:.6}._loader_axu61_1{animation:_rotate_axu61_1 1.5s linear infinite}@keyframes _rotate_axu61_1{0%{transform:rotate(0)}to{transform:rotate(360deg)}}._wrapper_1uxur_1{display:flex;flex-direction:column;position:fixed}._panel_1uxur_7{display:flex;flex-direction:column;padding:10px 6px 8px;background-color:#fafbfb;border-radius:8px;box-shadow:0 0 0 4px #ffffff3d,0 0 8px #00000040;overflow-y:auto}._panel_1uxur_7::-webkit-scrollbar{width:4px;height:4px}._panel_1uxur_7::-webkit-scrollbar-track,._panel_1uxur_7::-webkit-scrollbar-corner{background-color:#00000026}._panel_1uxur_7::-webkit-scrollbar-thumb{background-color:#0003!important;border-radius:4px}.v-enter-active[data-v-7bdf7098],.v-leave-active[data-v-7bdf7098]{transition:all .2s ease;transform:rotateX(0)}.v-enter-from[data-v-7bdf7098],.v-leave-to[data-v-7bdf7098]{opacity:0;transform:rotateX(-90deg)}._option_wdoq7_1{display:flex;gap:8px;font-size:12px;cursor:pointer;border-radius:6px;padding:4px 6px}._option__icon_wdoq7_9{height:20px;width:20px;min-width:20px;color:var(--7f83d9cb)}._option_wdoq7_1 span{line-height:20px;font-weight:var(--91ad83ca);color:#2d2f3c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}._option_wdoq7_1:hover{background-color:#f3f3f3}._option_wdoq7_1[disabled=true]{pointer-events:none}._option_wdoq7_1[disabled=true] span{color:#2d2f3c}._wrapper_10jns_1{display:flex;flex-direction:column}._label_10jns_6{font-size:12px;font-weight:400;color:#807a86}._options_10jns_12,._sourcepanel_1q8ve_1{display:flex;flex-direction:column}._sourcepanel__title_1q8ve_5{font-size:12px;padding:0 8px;font-weight:600;color:#2d2f3c}._sourcepanel__subtitle_1q8ve_11{padding:0 8px;color:#807a86;font-family:Rubik;font-size:10px;font-style:normal;font-weight:400;line-height:12px;margin-top:2px}._button_1fapy_1{border-radius:6px;border:2px solid rgba(128,122,134,.1);background:#f1f1f1;display:flex;padding:6px 8px;justify-content:center;align-items:center;height:32px;cursor:pointer;transition-duration:.2s;color:#807a86}._button_1fapy_1[disabled=true]{pointer-events:none;opacity:.8}._button__icon_1fapy_18{display:flex}._button__icon_1fapy_18 svg{height:20px;width:20px;min-width:20px}._button__icon_1fapy_18:nth-of-type(n + 2):before{content:"";width:1px;height:14px;background:rgba(128,122,134,.1);margin:0 10px;display:flex;align-self:center}._button_1fapy_1:hover{filter:brightness(.95)}._panel_1s6k3_1{padding:8px;border-radius:8px;display:flex;gap:8px;align-items:center;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:move;position:relative;overflow:visible}._smoothwidth_s2xf7_1{transition:width 1s cubic-bezier(.075,.82,.165,1);overflow:hidden}._wrapper_1495k_1{box-sizing:border-box;border-radius:8px;display:flex;background-color:#fafbfb;margin:8px;font-size:15px;font-family:Rubik,sans-serif,Arial,sans-serif;box-shadow:0 0 0 4px #ffffff3d,0 0 8px #00000040}._wrapper_1495k_1 *{box-sizing:border-box}.tw-pointer-events-none{pointer-events:none}.tw-static{position:static}.tw-absolute{position:absolute}.tw-relative{position:relative}.tw-inset-0{top:0px;right:0px;bottom:0px;left:0px}.tw-right-0{right:0px}.-tw-mt-\[2px\]{margin-top:-2px}.tw-mb-0{margin-bottom:0}.tw-mb-0\.5{margin-bottom:.125rem}.tw-mb-2{margin-bottom:8px}.tw-ml-2{margin-left:8px}.tw-ml-auto{margin-left:auto}.tw-mr-2{margin-right:8px}.tw-mt-1{margin-top:4px}.tw-mt-1\.5{margin-top:.375rem}.tw-mt-2{margin-top:8px}.tw-block{display:block}.tw-flex{display:flex}.tw-inline-flex{display:inline-flex}.tw-h-\[1em\]{height:1em}.tw-h-\[40px\]{height:40px}.tw-h-\[56px\]{height:56px}.tw-h-fit{height:-moz-fit-content;height:fit-content}.tw-h-full{height:100%}.\!tw-w-full{width:100%!important}.tw-w-\[1\.5rem\]{width:1.5rem}.tw-w-\[1em\]{width:1em}.tw-w-full{width:100%}.tw-min-w-\[1em\]{min-width:1em}.tw-grow{flex-grow:1}.tw-rotate-180{--tw-rotate: 180deg;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.tw-cursor-pointer{cursor:pointer}.tw-flex-col{flex-direction:column}.tw-items-center{align-items:center}.tw-items-stretch{align-items:stretch}.tw-justify-center{justify-content:center}.tw-justify-between{justify-content:space-between}.tw-gap-2{gap:8px}.tw-gap-4{gap:16px}.tw-gap-\[8px\]{gap:8px}.tw-overflow-hidden{overflow:hidden}.tw-overflow-visible{overflow:visible}.tw-overflow-y-auto{overflow-y:auto}.tw-rounded{border-radius:.25rem}.tw-rounded-md{border-radius:.375rem}.tw-border{border-width:1px}.tw-border-solid{border-style:solid}.tw-border-\[\#DADADA\]{--tw-border-opacity: 1;border-color:rgb(218 218 218 / var(--tw-border-opacity))}.tw-border-divider{--tw-border-opacity: 1;border-color:rgb(208 213 221 / var(--tw-border-opacity))}.tw-bg-\[\#33373E\]{--tw-bg-opacity: 1;background-color:rgb(51 55 62 / var(--tw-bg-opacity))}.tw-bg-\[\#4F545E\]{--tw-bg-opacity: 1;background-color:rgb(79 84 94 / var(--tw-bg-opacity))}.tw-bg-\[\#F3F3F3\]{--tw-bg-opacity: 1;background-color:rgb(243 243 243 / var(--tw-bg-opacity))}.tw-bg-\[\#FFFFFF\]{--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity))}.tw-bg-\[\#f5f5f5\]{--tw-bg-opacity: 1;background-color:rgb(245 245 245 / var(--tw-bg-opacity))}.tw-bg-active\/10{background-color:#41c5461a}.tw-bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity))}.tw-bg-left{background-position:left}.tw-bg-no-repeat{background-repeat:no-repeat}.tw-px-\[10px\]{padding-left:10px;padding-right:10px}.tw-px-\[12px\]{padding-left:12px;padding-right:12px}.tw-px-\[16px\]{padding-left:16px;padding-right:16px}.tw-px-\[8px\]{padding-left:8px;padding-right:8px}.tw-py-\[12px\]{padding-top:12px;padding-bottom:12px}.tw-py-\[6px\]{padding-top:6px;padding-bottom:6px}.tw-py-\[8px\]{padding-top:8px;padding-bottom:8px}.tw-pb-\[12px\]{padding-bottom:12px}.tw-pl-\[12px\]{padding-left:12px}.tw-pl-\[16px\]{padding-left:16px}.tw-pr-\[12px\]{padding-right:12px}.tw-pt-\[4px\]{padding-top:4px}.tw-text-right{text-align:right}.tw-align-baseline{vertical-align:baseline}.tw-text-\[10px\]{font-size:10px}.tw-text-\[11px\]{font-size:11px}.tw-text-\[16px\]{font-size:16px}.tw-text-\[1em\]{font-size:1em}.tw-text-default{font-size:13px}.tw-text-sm{font-size:.875rem;line-height:1.25rem}.tw-text-xs{font-size:.75rem;line-height:1rem}.tw-font-semibold{font-weight:600}.tw-leading-none{line-height:1}.tw-text-\[\#667085\]{--tw-text-opacity: 1;color:rgb(102 112 133 / var(--tw-text-opacity))}.tw-text-\[\#AAAAAA\]{--tw-text-opacity: 1;color:rgb(170 170 170 / var(--tw-text-opacity))}.tw-text-\[\#D9D9D9\]{--tw-text-opacity: 1;color:rgb(217 217 217 / var(--tw-text-opacity))}.tw-text-\[\#FFC700\]{--tw-text-opacity: 1;color:rgb(255 199 0 / var(--tw-text-opacity))}.tw-text-blue{--tw-text-opacity: 1;color:rgb(0 144 253 / var(--tw-text-opacity))}.tw-text-text-primary{--tw-text-opacity: 1;color:rgb(45 47 60 / var(--tw-text-opacity))}.tw-text-text-secondary{--tw-text-opacity: 1;color:rgb(179 179 179 / var(--tw-text-opacity))}.tw-opacity-50{opacity:.5}.tw-transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.hover\:tw-bg-\[rgba\(255\,255\,255\,0\.08\)\]:hover{background-color:#ffffff14}.hover\:tw-bg-gray-100:hover{--tw-bg-opacity: 1;background-color:rgb(243 244 246 / var(--tw-bg-opacity))}</style>
	
</head>
<body class="hold-transition sidebar-mini">
	<main class="d-flex flex-nowrap">
 <div class="flex-shrink-0 p-3" style="width: 280px;"> <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none"> <svg class="bi pe-none me-2" width="40" height="32" aria-hidden="true"><use xlink:href="#bootstrap"></use></svg> <span class="fs-4">Sidebar</span> </a> <hr> <ul class="nav nav-pills flex-column mb-auto"> <li class="nav-item"> <a href="#" class="nav-link active" aria-current="page"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true"><use xlink:href="#home"></use></svg>
Home
</a> </li> <li> <a href="#" class="nav-link link-body-emphasis"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true"><use xlink:href="#speedometer2"></use></svg>
Dashboard
</a> </li> <li> <a href="#" class="nav-link link-body-emphasis"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true"><use xlink:href="#table"></use></svg>
Orders
</a> </li> <li> <a href="#" class="nav-link link-body-emphasis"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true"><use xlink:href="#grid"></use></svg>
Products
</a> </li> <li> <a href="#" class="nav-link link-body-emphasis"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true"><use xlink:href="#people-circle"></use></svg>
Customers
</a> </li> </ul> <hr> <div class="dropdown"> <a href="#" class="d-flex align-items-center link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"> <img src="https://github.com/mdo.png" alt="" width="32" height="32" class="rounded-circle me-2"> <strong>mdo</strong> </a> <ul class="dropdown-menu text-small shadow"> <li><a class="dropdown-item" href="#">New project...</a></li> <li><a class="dropdown-item" href="#">Settings</a></li> <li><a class="dropdown-item" href="#">Profile</a></li> <li><hr class="dropdown-divider"></li> <li><a class="dropdown-item" href="#">Sign out</a></li> </ul> </div> </div>
		</main>
    <!-- Scripts -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="https://getbootstrap.com/docs/5.3/examples/sidebars/sidebars.js"></script>
</body>
</html>