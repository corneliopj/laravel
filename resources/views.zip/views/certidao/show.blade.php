<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Certidão de Registro - {{ $ave->matricula ?? 'Ave Desconhecida' }}</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="https://adminlte.io/themes/v3/dist/css/adminlte.min.css">
    <style>
        body {
            font-family: 'Source Sans Pro', sans-serif;
            background-color: #f4f6f9;
            padding: 20px;
        }
        .certidao-container {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 30px;
            margin: 20px auto;
            max-width: 800px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        .certidao-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #DAA520; /* Cor dourada */
            padding-bottom: 15px;
        }
        .certidao-header h1 {
            color: #DAA520; /* Cor dourada */
            font-size: 2.5em;
            margin-bottom: 5px;
        }
        .certidao-header p {
            font-size: 1.1em;
            color: #333; /* Preto */
        }
        .certidao-logo {
            margin-bottom: 15px;
        }
        .certidao-logo img {
            max-width: 100px; /* Tamanho do logo */
            height: auto;
        }
        .certidao-section {
            margin-bottom: 20px;
            border-bottom: 1px dashed #eee;
            padding-bottom: 15px;
        }
        .certidao-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        .certidao-section h4 {
            color: #333; /* Preto */
            margin-bottom: 15px;
            border-left: 4px solid #DAA520; /* Cor dourada */
            padding-left: 10px;
        }
        .certidao-data dt {
            font-weight: bold;
            color: #333; /* Preto */
        }
        .certidao-data dd {
            margin-bottom: 8px;
            color: #666; /* Tom de preto mais suave */
        }
        .certidao-footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            font-size: 0.9em;
            color: #777;
        }
        .certidao-qrcode {
            text-align: center;
            margin-top: 30px;
        }
        .certidao-qrcode img {
            border: 1px solid #ddd;
            padding: 5px;
            border-radius: 4px;
        }
        .validation-code {
            text-align: center;
            margin-top: 15px;
            font-size: 1.2em;
            font-weight: bold;
            color: #DAA520; /* Cor dourada */
        }
        .print-button-container {
            text-align: center;
            margin-top: 30px;
        }

        /* --- Estilos específicos para Impressão --- */
        @media print {
            body {
                background-color: #fff;
                margin: 0;
                padding: 0;
            }
            .certidao-container {
                box-shadow: none;
                border: none;
                margin: 0;
                padding: 0;
                max-width: none !important; /* Garante que a página ocupe toda a largura */
            }
            .print-button-container {
                display: none; /* Esconde o botão de imprimir */
            }

            /* Força as linhas e colunas a manterem o layout em impressão */
            .row {
                display: flex !important; /* Força o display flex para as linhas */
                flex-wrap: wrap !important; /* Permite quebrar se necessário, mas mantém a flexibilidade */
            }
            /* As classes col-md-6 devem manter 50% de largura mesmo em impressão */
            .col-md-6 {
                flex: 0 0 50% !important; /* Força a largura para 50% */
                max-width: 50% !important; /* Garante que não exceda 50% */
            }
            /* Garante que os elementos dentro das colunas não sejam cortados */
            .certidao-section {
                break-inside: avoid; /* Evita quebras de página dentro de seções */
            }
        }
    </style>
</head>
<body>
    <div class="certidao-container">
        <div class="certidao-header">
            <div class="certidao-logo">
                <img src="{{ asset('img/logo.png') }}" alt="Logo Criatório Coroné">
            </div>
            <h3>Criatório Coroné</h3>
            <h1>Certidão de Registro</h1>
            
        </div>

        <div class="row"> {{-- Início da linha para Dados da Ave e Informações Adicionais --}}
            <div class="col-md-6"> {{-- Primeira coluna para Dados da Ave --}}
                <div class="certidao-section">
                    <h4>Dados da Ave</h4>
                    <dl class="row certidao-data">
                        <dt class="col-sm-4">Matrícula:</dt>
                        <dd class="col-sm-8">{{ $ave->matricula ?? 'N/A' }}</dd>
                        <dt class="col-sm-4">Tipo de Ave:</dt>
                        <dd class="col-sm-8">{{ $ave->tipoAve->nome ?? 'N/A' }}</dd>
                        <dt class="col-sm-4">Variação:</dt>
                        <dd class="col-sm-8">{{ $ave->variacao->nome ?? 'N/A' }}</dd>
                        <dt class="col-sm-4">Sexo:</dt>
                        <dd class="col-sm-8">{{ $ave->sexo ?? 'N/A' }}</dd>
                        <dt class="col-sm-4">Data de Eclosão:</dt>
                        <dd class="col-sm-8">{{ $ave->data_eclosao ? $ave->data_eclosao->format('d/m/Y') : 'N/A' }}</dd>
                        <dt class="col-sm-4">Vendável:</dt>
                        <dd class="col-sm-8">{{ ($ave->vendavel ?? 0) ? 'Sim' : 'Não' }}</dd>
                        <dt class="col-sm-4">Data de Cadastro:</dt>
                        <dd class="col-sm-8">{{ $ave->created_at ? $ave->created_at->format('d/m/Y H:i:s') : 'N/A' }}</dd>
                    </dl>
                </div>
            </div>

            <div class="col-md-6"> {{-- Segunda coluna para Informações Adicionais e Morte --}}
                <div class="certidao-section">
                    <h4>Informações Adicionais</h4>
                    <dl class="row certidao-data">
                        <dt class="col-sm-4">Lote:</dt>
                        <dd class="col-sm-8">{{ $ave->lote->identificacao_lote ?? 'N/A' }}</dd>
                        <dt class="col-sm-4">Incubação (Origem):</dt>
                        <dd class="col-sm-8">
                            @if($ave->incubacao)
                                Lote: {{ $ave->incubacao->loteOvos->identificacao_lote ?? 'N/A' }} - Entrada: {{ $ave->incubacao->data_entrada_incubadora->format('d/m/Y') ?? 'N/A' }}
                            @else
                                N/A
                            @endif
                        </dd>
                    </dl>
                </div>

                <div class="certidao-section">
                    <h4>Informações de Morte</h4>
                    <dl class="row certidao-data">
                        @if ($ave->morte)
                            <dt class="col-sm-4">Status:</dt>
                            <dd class="col-sm-8"><span style="color: #dc3545; font-weight: bold;">Morreu</span> (Data: {{ $ave->morte->data_morte ? $ave->morte->data_morte->format('d/m/Y') : 'N/A' }})</dd>
                            <dt class="col-sm-4">Causa:</dt>
                            <dd class="col-sm-8">{{ $ave->morte->causa ?? 'Não informada' }}</dd>
                            <dt class="col-sm-4">Observações:</dt>
                            <dd class="col-sm-8">{{ $ave->morte->observacoes ?? 'N/A' }}</dd>
                        @else
                            <dt class="col-sm-4">Status:</dt>
                            <dd class="col-sm-8"><span style="color: #28a745; font-weight: bold;">Viva</span></dd>
                        @endif
                    </dl>
                </div>
            </div>
        </div> {{-- Fim da linha para Dados da Ave e Informações Adicionais --}}

        <div class="row mt-4"> {{-- Linha para Foto e QR Code --}}
            <div class="col-md-6"> {{-- Coluna para Foto da Ave --}}
                @if ($ave->foto_path)
                    <div class="certidao-section text-center">
                        <h4>Foto da Ave</h4>
                        <img src="{{ asset($ave->foto_path) }}" alt="Foto da Ave" class="img-fluid" style="max-width: 300px; height: auto; border-radius: 8px; border: 1px solid #ddd; padding: 5px;">
                    </div>
                @endif
            </div>

            <div class="col-md-6"> {{-- Coluna para Código de Validação e QR Code --}}
                <div class="certidao-qrcode certidao-section">
                    <h4>Código de Validação</h4>
                    {{-- QR Code que aponta para a rota pública da certidão --}}
                    @if ($ave->validation_code)
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={{ urlencode(route('certidao.show', ['validation_code' => $ave->validation_code])) }}" alt="QR Code de Validação">
                        <div class="validation-code">
                            Código de Validação: {{ $ave->validation_code }}
                        </div>
                    @else
                        <p>Nenhum código de validação disponível.</p>
                    @endif
                </div>
            </div>
        </div> {{-- Fim da linha para Foto e QR Code --}}

        <div class="certidao-footer">
            <p>Documento gerado em {{ \Carbon\Carbon::now()->format('d/m/Y H:i:s') }}</p>
            <p>Este documento é válido apenas com o código de validação e QR Code acima.</p>
			Linha 176, km3.5 - norte - Santa Luzia dOeste - RO<br> http://www.corone.com.br<br>
        </div>
    </div>

    <div class="print-button-container">
        <button onclick="window.print()" class="btn btn-primary">Imprimir Certidão</button>
    </div>

</body>
</html>
